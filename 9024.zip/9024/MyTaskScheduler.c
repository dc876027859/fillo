#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

// This assignment, due to my poor grasp of the binomial heap-based priority queue,
// I only completed the functions of the void insert () part
// and the int Min () part according to the requirements of the assignment paper.
// For the task scheduler part, because the function of HeapNode * RemoveMin () part is not completed,
// the output of the scheduler cannot be printed.
// First merge the binomial heap to build a new binomial heap,
// Complete the addition of a binomial heap through the program in the BinomialHeap * mergeHeaps () function part.
// Then deal with the addition of the binomial heap, through the function of the void mergeHeapToBinomialHeaps () part,
// complete the merge operation of a heap to another existing binomial heaps.
// Then completed is the Min () function, this function is mainly to find the minimum value in the binomial heap and return.


// This template is only a guide 
// You need to include additional fields, data structures and functions



// data type for heap nodes
typedef struct HeapNode {
    // each node stores the priority (key), name, execution time,
    //  release time and deadline of one task
    int key; //key of this task
    int TaskName;  //task name
    int Etime; //execution time of this task
    int Rtime; // release time of this task
    int Dline; // deadline of this task
    // add additional fields here
    struct HeapNode *siblings;
    struct HeapNode *children;
} HeapNode;



//data type for a priority queue (heap) 
typedef struct BinomialHeap { //this is heap header
    int size;      // count of items in the heap
    // In order to determine a binomial heap, you need to determine who is its next location, and root,
    // so we define the next and the root.
    struct HeapNode *root;
    struct BinomialHeap *next;
} BinomialHeap;



//data type for a priority queue (heap)
typedef struct BinomialHeaps { //this is heap header
    int size;      // count of items in the heap
    struct BinomialHeap *first;
} BinomialHeaps;



// create a new heap node to store an item (task) 
HeapNode *newHeapNode(int k, int n, int c, int r, int d) { // k:key, n:task name, c: execution time, r:release time, d:deadline
    // ... you need to define other parameters yourself)
    HeapNode *new;
    new = malloc(sizeof(HeapNode));
    assert(new != NULL);
    new->key = k;
    new->TaskName = n;
    new->Etime = c;
    new->Rtime = r;
    new->Dline = d;
    // initialise other fields
    new->siblings = NULL;
    new->children = NULL;
    return new;
}



BinomialHeap *newHeap() {
    BinomialHeap *new;
    new = malloc(sizeof(BinomialHeap));
    assert (new != NULL);
    // Clear all existing data.
    new->size = 0;
    new->next = NULL;
    new->root = NULL;
    return new;
}



// create a new empty heap-based priority queue
BinomialHeaps *newHeaps() { // this function creates an empty binomial heap-based priority queue
    BinomialHeaps *T;
    T = malloc(sizeof(BinomialHeaps));
    assert (T != NULL);
    // initialise all the fields here
    T->size = 0;
    T->first = NULL;
    return T;
}
//========================================================================//



int compareTo(int k1, int t1, int k2, int t2) {
    int result = 0;
    // value 相等的情况比较key
    if (k1 == k2) {
        if (t1 != t2) {
            result = t1  > t2 ? 1 : -1;
        }
    } else {
        result = k1 > k2 ? 1 : -1;
    }
    return result;
}



// Check the binomial heap to ensure that there are no erroneous items and blank data content
// Suppose first root is always smaller than second root
BinomialHeap *mergeHeaps(BinomialHeap *first, BinomialHeap *second) {

    if (first->size == 0) {
        free(first);
        return second;
    }
    if (second->size == 0) {
        free(second);
        return first;
    }

    // Compare the size of the two tasks obtained
    if (compareTo(first->root->key, first->root->TaskName, second->root->key, second->root->TaskName) > 0) {
        // Then exchange the first and second data
        return mergeHeaps(second, first);
    }
    // When the first value is already smaller than the second value
    if (first->root->children == NULL) {
        // When the first is smaller than the second, they are merged and the size becomes the sum of the two
        first->root->children = second->root;
        first->size = first->size + second->size;
        // Then the second does not need to exist because the merger has been completed, so the second is emptied
        free(second);
        return first;
    } else {
        // Otherwise, if the child is not empty, then find the last sibling of the first
        HeapNode *tempNode = first->root->children;
        while (tempNode->siblings != NULL) {
            tempNode = tempNode->siblings;
        }
        // Then merge with second, after second transfer, change the size of first, and clear second
        tempNode->siblings = second->root;
        first->size = first->size + second->size;
        free(second);
        return first;
    }
}


// Operate on an existing binomial heaps to complete the merge operation with a new heap
void mergeBinomialHeaps(BinomialHeap *heap, BinomialHeaps *heaps) {
    // Judgment condition, if the merged heap is empty or the size is zero, then keep the original heaps unchanged
    if (heap != NULL && heap->size > 0) {
        if (heaps->first == NULL) {
            heaps->first = heap;
        } else {
            // Otherwise, when first is not equal to empty
            // If the position of the first node is already equal
            if (heap->size == heaps->first->size) {
                BinomialHeap *mergeHeap = heaps->first;
                // The binomial heap points to first, and then judges the next point of heap, which is next
                heaps->first = heaps->first->next;
                mergeHeap->next = NULL;
                mergeHeap = mergeHeaps(heap, mergeHeap);
                mergeBinomialHeaps(mergeHeap, heaps);
            } else {
                // Otherwise, start to compare the size of the heap at the next position.
                BinomialHeap *pre = heaps->first;
                BinomialHeap *second = heaps->first->next;
                while (second != NULL) {
                    if (second->size == heap->size) {
                        break;
                    }
                    pre = pre->next;
                    second = second->next;
                }
                // If second is empty, it means that no equal heap was found.
                if (second == NULL) {
                    pre->next = heap;
                } else {
                    // On the contrary, it means that an equal second has been found and the two need to be disconnected.
                    pre->next = second->next;
                    second->next = NULL;
                    BinomialHeap *mergeHeap = mergeHeaps(heap, second);
                    mergeBinomialHeaps(mergeHeap, heaps);
                }
            }
        }
    }
}



// put the time complexity analysis for Insert() here
// The while() function is used to merge the binomial heaps, When it finds an equal data,
// it records the position and finds the equal binomial heap again by using while() function.
// Therefore, the algorithm complexity of insert is O(n).
void Insert(BinomialHeaps *T, int k, int n, int c, int r, int d) { // k: key, n: task name, c: execution time, r: release time, d:deadline
    // You don't need to check if this task already exists in T
    //put your code here

    HeapNode *newNode = newHeapNode(k, n, c, r, d);
    BinomialHeap *NewHeap = newHeap();
    NewHeap->root = newNode;
    NewHeap->next = NULL;
    NewHeap->size = 1;
    mergeBinomialHeaps(NewHeap, T);
    T->size = T->size + 1;
}



// Read the data in 4 samples through EOF
// Store the corresponding data and correspond to the specific value with the data type defined in HeapNode
void readTasksFromFile(char *fileName, BinomialHeaps *T) {
    FILE *file = fopen(fileName, "r");
    if (file != NULL) {
        int v, c, r, d;
        // Read all the data in the file one by one in order
        while (fscanf(file, "%d %d %d %d", &v, &c, &r, &d) != EOF) {
            Insert(T, r, v, c, r, d);
        }
        fclose(file);
    }
}



// put your time complexity for RemoveMin() here
HeapNode *RemoveMin(BinomialHeaps *T) {
    // put your code here
}



int Min(BinomialHeaps *T) {
    // put your code here
    int result = 0;
    if (T != NULL && T->size > 0) {
        BinomialHeap *first = T->first;
        result = first->root->key;
        while (first->next != NULL && first->next->root != NULL) {
            if (result > first->next->root->key) {
                result = first->next->root->key;
            }
            first = first->next;
        }
    }
    return result;

}



// put your time complexity analysis for MyTaskScheduler here
int TaskScheduler(char *f1, char *f2, int m) {
    // put your code here
    int result = 1;
    BinomialHeaps *rHeaps = newHeaps();
    BinomialHeaps *dHeaps = newHeaps();

    readTasksFromFile(f1, rHeaps);

    // Whenever the current start time of each core task is equal to the start time of 0
    int timeFrame = 0;
    int *cores = malloc(m * sizeof(int));
    for (int i = 0; i < m; i++) {
        cores[i] = 0;
    }

    FILE *file = fopen(f2, "w");

    // Find the smallest core and value
    int minCoreValue = 2048;
    int MinValue = 2048;
    // Judging that when there is a core, it means that there must be a task being executed
    while (rHeaps->size > 0 || dHeaps->size > 0) {
        // When no task is executed
        if (dHeaps->size == 0) {
            //
            if (timeFrame < Min(rHeaps)) {
                timeFrame = Min(rHeaps);
            }
        }
        for (int i = 0; i < m; i++) {
            if (cores[i] < timeFrame) {
                cores[i] = timeFrame;
            }
        }

        while (rHeaps->size > 0 && Min(rHeaps) <= timeFrame) {
            HeapNode *node = Min(rHeaps);
            Insert(dHeaps, node->Dline, node->TaskName, node->Etime, node->Rtime, node->Dline);
        }
        // Find the earliest task to submit
        HeapNode *deadlineNode = Min(dHeaps);
        // Get the smallest value and index in cores


        //If the minimum core plus the expected execution time are later than the deadline,
        // it means that there is no free core allocation
        if (minCoreValue + deadlineNode->Etime <= deadlineNode->Dline) {
            // print result;
            fprintf(file, "%d Core%d %d ", deadlineNode->TaskName, MinValue, minCoreValue);
            cores[MinValue] = cores[MinValue] + deadlineNode->Etime;
        } else {
            printf("\nwhere task %d misses its deadline.\n", deadlineNode->TaskName);
            result = 0;
            break;
        }
        // Clear memory
        free(deadlineNode);
    }
    // Clear memory and close file
    fclose(file);
    free(cores);
    return result;
}



int main() //sample main for testing
{
    int i;
    i = TaskScheduler("samplefile1.txt", "feasibleschedule1.txt", 4);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is a feasible schedule on 4 cores */
    i = TaskScheduler("samplefile1.txt", "feasibleschedule2.txt", 3);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is no feasible schedule on 3 cores */
    i = TaskScheduler("samplefile2.txt", "feasibleschedule3.txt", 5);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is a feasible schedule on 5 cores */
    i = TaskScheduler("samplefile2.txt", "feasibleschedule4.txt", 4);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is no feasible schedule on 4 cores */
    i = TaskScheduler("samplefile3.txt", "feasibleschedule5.txt", 2);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is no feasible schedule on 2 cores */
    i = TaskScheduler("samplefile4.txt", "feasibleschedule6.txt", 2);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is a feasible schedule on 2 cores */
    return 0;
}

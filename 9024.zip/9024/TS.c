#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

// This template is only a guide 
// You need to include additional fields, data structures and functions




// data type for heap nodes
typedef struct HeapNode {
    // each node stores the priority (key), name, execution time,
    //  release time and deadline of one task
    int key; //key of this task
    int TaskName;  //task name
    int Etime; //execution time of this task
    int Rtime; // release time of this task
    int Dline; // deadline of this task
    // add additional fields here
    // 兄弟姐妹
    struct HeapNode *siblings;
    // 所有的孩子
    struct HeapNode *children;
    int size; // number of nodes
    int depth;
} HeapNode;

//data type for a priority queue (heap) 
typedef struct BinomialHeap { //this is heap header
    int size;      // count of items in the heap
    struct HeapNode *root;
    struct BinomialHeap *next;
} BinomialHeap;


// 1.heap,
// 2.after merge
//  BinomialHeaps
// k = log(n)
// k /log(n)
//               first
//   11    ->     15      ->   20     ->         30
//                 20         30 40          40  50  30
//                              50            60  70   80
//
//              second
//   9    ->     13      ->   15     ->         20
//                 20         30 40          40  50  30
//                              50            60  70   80
//
// third
// 9
//  11
//

//data type for a priority queue (heap)
typedef struct BinomialHeaps { //this is heap header
    int size;      // count of items in the heap
    struct BinomialHeap *first;
} BinomialHeaps;


// create a new heap node to store an item (task) 
HeapNode *newHeapNode(int k, int n, int c, int r, int d,
                      ...) { // k:key, n:task name, c: execution time, r:release time, d:deadline
    // ... you need to define other parameters yourself)
    HeapNode *new;
    new = malloc(sizeof(HeapNode));
    assert(new != NULL);
    new->key = k;
    new->TaskName = n;
    new->Etime = c;
    new->Rtime = r;
    new->Dline = d;
    // initialise other fields
    new->siblings = NULL;
    new->children = NULL;
    return new;
}

BinomialHeap *newHeap() {
    BinomialHeap *new;
    new = malloc(sizeof(BinomialHeap));
    assert (new != NULL);

    new->size = 0;
    new->next = NULL;
    new->root = NULL;

    return new;
}

// create a new empty heap-based priority queue
BinomialHeaps *newHeaps() { // this function creates an empty binomial heap-based priority queue
    BinomialHeaps *T;
    T = malloc(sizeof(BinomialHeaps));
    assert (T != NULL);
    // initialise all the fields here
    T->size = 0;
    T->first = NULL;
    return T;
}

/**
 * 加上任务的比较
 * @param key01
 * @param task01
 * @param key02
 * @param task02
 * @return
 */
int compareTo(int key01, int task01, int key02, int task02) {
    int result = 0;
    // value 相等的情况比较key
    if (key01 == key02) {
        if (task01 != task02) {
            result = task01  > task02 ? 1 : -1;
        }
    } else {
        result = key01 > key02 ? 1 : -1;
    }
    return result;
}

BinomialHeap *mergeTwoHeaps(BinomialHeap *first, BinomialHeap *second) {
    if (first == NULL) {
        return second;
    }
    if (second == NULL) {
        return first;
    }
    if (first->size == 0) {
        free(first);
        return second;
    }
    if (second->size == 0) {
        free(second);
        return first;
    }

    // 比较两个任务谁大谁小
    if (compareTo(first->root->key, first->root->TaskName, second->root->key, second->root->TaskName) > 0) {
        return mergeTwoHeaps(second, first);
    }
    // if (first->root->key > second->root->key) {
    //    return mergeTwoHeaps(second, first);
    // }
    //      11
    //    20  30
    //        40


    //     15
    //   30   40
    // 60
    if (first->root->children == NULL) {
        // first  11
        // second 12

        //     11
        //       12
        first->root->children = second->root;
        first->size = first->size + second->size;
        free(second);
        return first;
    } else {
        HeapNode *tempNode = first->root->children;
        while (tempNode->siblings != NULL) {
            tempNode = tempNode->siblings;
        }
        tempNode->siblings = second->root;
        first->size = first->size + second->size;
        free(second);
        return first;
    }
}

void mergeHeapToBinomialHeaps(BinomialHeap *heap, BinomialHeaps *heaps) {
    // heap
    //   12
    // 30  100
    //      200

    // heaps
//  BinomialHeaps
//   11    x     15      ->   20     ->         30
//                 20         30 40          40  50  30
//                              50            60  70   80
//
    if (heap != NULL && heap->size > 0) {
        if (heaps->first == NULL) {
            heaps->first = heap;
        } else {
            // 如果第一个node就相等
            if (heap->size == heaps->first->size) {
                BinomialHeap *mergeHeap = heaps->first;
                heaps->first = heaps->first->next;
                mergeHeap->next = NULL;
                mergeHeap = mergeTwoHeaps(heap, mergeHeap);
                // 11
                //   12
                mergeHeapToBinomialHeaps(mergeHeap, heaps);
            } else {
                BinomialHeap *pre = heaps->first;
                BinomialHeap *second = heaps->first->next;
                while (second != NULL) {
                    if (second->size == heap->size) {
                        // heap
                        //   12
                        // 30  100
                        //      200

                        //  BinomialHeaps
                        //               first        second
                        //   11    ->     15      ->   20     ->         30
                        //                 20         30 40          40  50  30
                        //                              50            60  70   80
                        break;
                    }
                    pre = pre->next;
                    second = second->next;
                }
                if (second == NULL) {
                    pre->next = heap;
                } else {
                    // heap
                    //   12
                    // 30  100
                    //      200

                    // n
                    // log（n) = k
                    //  k-1,k-2,k-3  1
                    // k*(k-1)/2

                    // 1,2 ,3 ,4 ,5 ,6,8,10(k个点）
                    // 1,2

                    // 1，2,4,8,16,32
                    //   4

                    // k = log(n)
                    // (logn)的平方
                    //  BinomialHeaps
                    //               first        second
                    //   11    ->     15      ->   20     ->         30
                    //                 20         30 40          40  50  30
                    //                              50            60  70   80
                    pre->next = second->next;
                    second->next = NULL;
                    BinomialHeap *mergeHeap = mergeTwoHeaps(heap, second);
                    mergeHeapToBinomialHeaps(mergeHeap, heaps);
                }
            }
        }
    }
}


// put the time complexity analysis for Insert() here
// insert complexity
void Insert(BinomialHeaps *T, int k, int n, int c, int r,
            int d) { // k: key, n: task name, c: execution time, r: release time, d:deadline
    // You don't need to check if this task already exists in T
    //put your code here

    HeapNode *newNode = newHeapNode(k, n, c, r, d);
    BinomialHeap *new_heap = newHeap();
    new_heap->root = newNode;
    new_heap->next = NULL;
    new_heap->size = 1;
    mergeHeapToBinomialHeaps(new_heap, T);
    T->size = T->size + 1;
}

int sizeOfHeapNode(HeapNode *tempNode) {
    int result = 0;

    if (tempNode != NULL) {
        result = result + sizeOfHeapNode(tempNode->siblings);
        result = result + sizeOfHeapNode(tempNode->children);
        result++;
    }


    return result;
}


// put your time complexity for RemoveMin() here
HeapNode *RemoveMin(BinomialHeaps *T) {
    // put your code here
    //               first        second
    //   11    ->     15      ->   10     ->         30
    //                 20         30 40          40  50  30
    //                              50            60  70   80

    // 30   40
    //        50



    // 11
    //   30

    // 40        11
    //   50    15   30
    //          20
    HeapNode *result = NULL;
    if (T != NULL && T->size > 0) {
        BinomialHeap *second = T->first->next;
        BinomialHeap *first = T->first;

        BinomialHeap *minHeapPre = T->first, *minHeap = T->first;
        result = first->root;
        while (second != NULL && second->root != NULL) {
            if (compareTo(second->root->key,second->root->TaskName, first->root->key,first->root->TaskName) < 0) {
            // if (second->root->key < result->key) {
                // 找到最小值
                result = second->root;
                minHeapPre = first;
                minHeap = second;
            }
            first = first->next;
            second = second->next;
        }

        // heaps 断开操作
        if (minHeap == T->first) {
            T->first = minHeap->next;
            minHeap->next = NULL;
        } else {
            minHeapPre->next = minHeap->next;
            minHeap->next = NULL;
        }

        //    10
        // 30 -> 40
        //        50
        HeapNode *tempNode = minHeap->root->children;
        HeapNode *next = NULL;
        while (tempNode != NULL) {
            // tempNode 30
            // next 40
            next = tempNode->siblings;
            tempNode->siblings = NULL;
            BinomialHeap *new_heap = newHeap();
            new_heap->root = tempNode;
            new_heap->next = NULL;
            new_heap->size = sizeOfHeapNode(tempNode);
            mergeHeapToBinomialHeaps(new_heap, T);
            // next 是40
            // 所以tempnode 是40
            tempNode = next;
        }

        T->size = T->size - 1;
    }
    return result;
}

int Min(BinomialHeaps *T) {
    // put your code here
    int result = 0;
    if (T != NULL && T->size > 0) {
        BinomialHeap *first = T->first;
        result = first->root->key;
        while (first->next != NULL && first->next->root != NULL) {
            if (result > first->next->root->key) {
                result = first->next->root->key;
            }
            first = first->next;
        }
    }
    return result;

}

void readTasksFromFile(char *fileName, BinomialHeaps *T) {
    FILE *file = fopen(fileName, "r");
    if (file != NULL) {
        int v, c, r, d;
        while (fscanf(file, "%d %d %d %d", &v, &c, &r, &d) != EOF) {
            Insert(T, r, v, c, r, d);
        }

        fclose(file);
    }

}


void getMinIndexAndMinValue(const int *cores, int n, int *coreIndex, int *coreValue) {
    *coreValue = 999999;
    // core最小就意味着可能空闲
    for (int i = 0; i < n; i++) {
        if (*coreValue > cores[i]) {
            *coreValue = cores[i];
            *coreIndex = i;
        }
    }
}

// put your time complexity analysis for MyTaskScheduler here
int TaskScheduler(char *f1, char *f2, int m) {
    // put your code here
    int result = 1;
    BinomialHeaps *releasedHeaps = newHeaps();
    BinomialHeaps *deadlineHeaps = newHeaps();

    readTasksFromFile(f1, releasedHeaps);

    // 当前每一个core任务开始时间为0
    int timeFrame = 0;
    int *cores = malloc(m * sizeof(int));
    for (int i = 0; i < m; i++) {
        cores[i] = 0;
    }

    FILE *file = fopen(f2, "w");

    // 找最小的core和value
    int minCoreValue = 99999999;
    int coreOfMinValue = 99999999;
    // 肯定有任务在执行
    while (releasedHeaps->size > 0 || deadlineHeaps->size > 0) {
        //
        // 如果没有任务执行了
        if (deadlineHeaps->size == 0) {
            //
            if (timeFrame < Min(releasedHeaps)) {
                timeFrame = Min(releasedHeaps);
            }
        }
        for (int i = 0; i < m; i++) {
            // 修正 少了一个if条件
            if (cores[i] < timeFrame) {
                cores[i] = timeFrame;
            }
        }
        // core1 9 2 12
        // core2 9 1 10
        // core2 12
        // 9 2 13
        // 9 5 14
        // insert 5个
        while (releasedHeaps->size > 0 && Min(releasedHeaps) <= timeFrame) {
            HeapNode *node = RemoveMin(releasedHeaps);
            Insert(deadlineHeaps, node->Dline, node->TaskName, node->Etime,
                   node->Rtime, node->Dline);
        }
        // 最早要交作业的那个
        HeapNode *deadlineNode = RemoveMin(deadlineHeaps);
        // 获取cores里面最小的value和index
        getMinIndexAndMinValue(cores, m, &coreOfMinValue, &minCoreValue);

        // 如果最小的core + 我预期执行的时间，都晚于deadline，没有空闲的core分配
        if (minCoreValue + deadlineNode->Etime <= deadlineNode->Dline) {
            // print result;
            fprintf(file, "%d Core%d %d ", deadlineNode->TaskName, coreOfMinValue + 1, minCoreValue);
            cores[coreOfMinValue] = cores[coreOfMinValue] + deadlineNode->Etime;
        } else {
            printf("\nwhere task %d misses its deadline.\n", deadlineNode->TaskName);
            result = 0;
            break;
        }
        // 获取cores里面最小的value和index
        getMinIndexAndMinValue(cores, m, &coreOfMinValue, &timeFrame);
        free(deadlineNode);
    }
    fclose(file);
    free(cores);

    return result;
}

int main() //sample main for testing 
{
    int i;
    i = TaskScheduler("samplefile1.txt", "feasibleschedule1.txt", 4);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is a feasible schedule on 4 cores */
    i = TaskScheduler("samplefile1.txt", "feasibleschedule2.txt", 3);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is no feasible schedule on 3 cores */
    i = TaskScheduler("samplefile2.txt", "feasibleschedule3.txt", 5);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is a feasible schedule on 5 cores */
    i = TaskScheduler("samplefile2.txt", "feasibleschedule4.txt", 4);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is no feasible schedule on 4 cores */
    i = TaskScheduler("samplefile3.txt", "feasibleschedule5.txt", 2);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is no feasible schedule on 2 cores */
    i = TaskScheduler("samplefile4.txt", "feasibleschedule6.txt", 2);
    if (i == 0) printf("No feasible schedule!\n");
    /* There is a feasible schedule on 2 cores */
    return 0;
}

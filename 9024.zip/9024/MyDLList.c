#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

#define MAXSTRING 1000
#define DELIM " \r\n"

// all the basic data structures and functions are included in this template
// you can add your own auxiliary functions as you like

// data structures representing DLList

typedef struct DLListNode {
    int value;  // value (int) of this list item
    struct DLListNode *prev;
    // pointer previous node in list
    struct DLListNode *next;
    // pointer to next node in list
} DLListNode;

//data type for doubly linked lists
typedef struct DLList {
    int size;      // count of items in list
    DLListNode *first; // first node in list
    DLListNode *last;  // last node in list
} DLList;

// create a new DLListNode
DLListNode *newDLListNode(int it) {
    DLListNode *new;
    new = malloc(sizeof(DLListNode));
    assert(new != NULL);
    new->value = it;
    new->prev = new->next = NULL;
    return new;
}

// create a new empty DLList
DLList *newDLList() {
    DLList *L;

    L = malloc(sizeof(struct DLList));
    assert (L != NULL);
    L->size = 0;
    L->first = NULL;
    L->last = NULL;
    return L;
}

// code writing
/* time complexity analysis: for insert part, the function only check data by using 'if' function
   by checking if the list pointer is NULL or not to input data from file
   so the time complexity is O(1).*/
void insertList(DLList *list, int data) {
    // create new node
    DLListNode *pointer = newDLListNode(data);
    if (list != NULL) {
        if (list->first == NULL) {
            list->first = pointer;
            list->last = pointer;
            list->size++;
        } else {
            pointer->prev = list->last;
            list->last->next = pointer;
            list->last = pointer;
            list->size++;
        }
    }

}


// free up all space associated with list
// put your time complexity analysis for freeDLList() here
/* Time complexity analysis: To check all elements in DLList, FreeDLList code check all of it by 'while' function
   So the Time Complexity should be O(n). */
void freeDLList(DLList *L) {
// put your code here
    if (L != NULL){
        if (L->size != 0) {
        if (L->size > 0) {
            DLListNode *first = L->first;
            DLListNode *position;
            while (first != NULL) {
                position = first;
                first = first->next;
                free(position);
            }
            free(L);
        }
    }
}
}

// create a DLList from a text file
// put your time complexity analysis for CreateDLListFromFileDlist() here
/* time complexitu analysis: to creat a new list from file, we check every elements one by one
   by using 'while' function
   for the data which is corrcet, then use 'for' function to print
   so the time complexity is O(n^2). */
DLList *CreateDLListFromFileDlist(const char *filestation) {
    // put your code here
    FILE *file = NULL;
    // read file context
    DLList *result = newDLList();

    bool correctInput = true;

    if (strcmp(filestation, "stdin") == 0) {
        char word[1024];
        int input = 0, index = 0;
        while ((input = getchar()) != EOF) {
            if (!isalnum(input)) {
                if (strlen(word) > 0) {
                    if (strcmp(word, "end") == 0) {
                        break;
                    }
                    for(int i=0; i<strlen(word); i++) {
                        if (isdigit(word[i]) == 0) {
                            correctInput = 0;
                            puts("Invalid input!");
                            break;
                        }
                    }
                    if (correctInput == 0) {
                        break;
                    }
                    insertList(result, atoi(word));
                }
                index = 0;
            } else {
                word[index] = input;
                index++;
            }
            word[index] = '\0';
        }

    }
    else {
        file = fopen(filestation, "r");
        if (file == NULL) {
            correctInput = 0;
            puts("Invalid input!");
        } else {
            char line[MAXSTRING];
            char *getword;

            while (fgets(line, MAXSTRING, file) != NULL) {
                /* first token */
                getword = strtok(line, DELIM);

                while (getword != NULL) {
                    for (int i = 0; i < strlen(getword); i++) {
                        if (getword[i] == '-') {
                            continue;
                        }
                        if (isdigit(getword[i]) == 0) {
                            correctInput = 0;
                            puts("Invalid input!");
                            break;
                        }
                    }
                    insertList(result, atoi(getword));
                    // continue to get string
                    getword = strtok(NULL, DELIM);
                }

                if (correctInput == 0) {
                    break;
                }
            }
            fclose(file);
        }
    }

    if (correctInput == 0) {
        freeDLList(result);
        result = NULL;
    }

    return result;
}

// clone a DLList
// put your time complexity analysis for cloneList() here
/* Time complexity analysis: To clone a new list from the DLList, 'if' and 'while' functions check all elements which is
   not NULL and not a negative number and then point it.
   So the Time Complexity should be O(n)*/
DLList *cloneList(DLList *u) {
    // put your code here

    DLList *result = NULL;
    if (u != NULL){
        if(u->size > 0) {
        result = newDLList();
        DLListNode *first = u->first;
        while (first != NULL) {
            insertList(result, first->value);
            first = first->next;
        }
    }
}
    return result;
}

bool exists(DLList *u, int getnum) {
    bool result = 0;
    if (u != NULL){
        if(u->size > 0) {
        DLListNode *first = u->first;
        while (first != NULL) {
            if (first->value == getnum) {
                result = 1;
                break;
            }
            first = first->next;
        }
    }
    }
    return result;
}

// compute the union of two DLLists u and v
///* time complexity analysis: if we assume the length of set A is N, and the length of set B is M
//   then the time complexity is N*M because 'while' function caculate them independently.
//   So the time complexity is O(N*M). */
DLList *setUnion(DLList *u, DLList *v) {
    if (u == NULL) {
        return cloneList(v);
    }

    if (v == NULL) {
        return cloneList(u);
    }


    DLList *result = cloneList(u);
    DLListNode *first = v->first;
    while (first != NULL) {

        if (exists(u, first->value) == 0) {
            insertList(result, first->value);
        }
        first = first->next;
    }

    return result;

}

// compute the insection of two DLLists u and v
// put your time complexity analysis for intersection() here
/* time complexity analysis: if we assume the length of set A is N, and the length of set B is M
   then the time complexity is N*M because 'for' function caculate them independently.
   So the time complexity is O(N*M). */
DLList *setIntersection(DLList *u, DLList *v) {
    // put your code here
    if (v != NULL || u != NULL) {
        DLList *result = newDLList();
        DLListNode *first;

        for (first = u->first; first != NULL; first ->next ){
            if (exists(v, first->value) == 1) {
                insertList(result, first->value);
            }
            first = first->next;
        }

        return result;
    }
    else {
        return NULL;
    }
}



// display items of a DLList
// put your time complexity analysis for printDDList() here
/* time complexity analysis: For printDDList,the pointer 'u' in DDList check and print 'u' one by one
   No cycle in this function so the time complexity is O(1). */
void printDLListNode(DLListNode *first) {
    if (first!=NULL) {
        printf("%d\n", first->value);
        printDLListNode(first->next);
    }
}
void printDLList(DLList *u) {
    // put your code here
    if (u != NULL){
        if (u->size > 0) {
            printDLListNode(u->first);
        }
    }

}

int main() {
    DLList *list1, *list2, *list3, *list4, *list5, *list6;

    list1 = CreateDLListFromFileDlist("File1.txt");
    printDLList(list1);

    list2 = CreateDLListFromFileDlist("File2.txt");
    printDLList(list2);

    list3 = setUnion(list1, list2);
    printDLList(list3);

    list4 = setIntersection(list1, list2);
    printDLList(list4);

    freeDLList(list1);
    freeDLList(list2);
    freeDLList(list3);
    freeDLList(list4);

    printf("please type all the integers of list1\n");
    list1 = CreateDLListFromFileDlist("stdin");

    printf("please type all the integers of list2\n");
    list2 = CreateDLListFromFileDlist("stdin");

    list3 = cloneList(list1);
    printDLList(list3);
    list4 = cloneList(list2);
    printDLList(list4);

    printf("Set Union: \n");
    list5 = setUnion(list1, list2);
    printDLList(list5);
    list6 = setIntersection(list1,list2);
    printf("Set Intersection: \n");
    printDLList(list6);

    freeDLList(list1);
    freeDLList(list2);
    freeDLList(list3);
    freeDLList(list4);

    return 0;
}

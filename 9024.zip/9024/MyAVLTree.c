/*
 * For the entire program, after creating the necessary AVLTreeNode, start implementing the CreatAVLTree() function,
 * At the same time, since an AVLTree operation is performed.
 *
 * Also, in order to make the tree reach equilibrium,
 * the height of the tree needs to be defined and continuously adjusted in subsequent operations,
 * so define a TreeHeight() function to monitor the height of the tree.
 *
 * For an AVLTree, it is necessary to constantly check whether the tree has reached equilibrium,
 * so it is necessary to constantly compare the sizes between different nodes. we define the function named
 * strcmp_result(), by constantly recursively comparing the size of the nodes,
 * the new value is constantly returned，to complete functions such as insertion and deletion.
 *
 * For an unbalanced tree, we need to perform continuous left and right rotations to achieve the balance of the AVLtree.
 * At the same time, for an AVLTree,
 * the balancing conditions to be judged are whether the left subtree is balanced and the right subtree is balanced,
 * so the two judgment conditions need to be processed separately.
 * in this program they are RotateLeft() and RotateRight() functions.
 *
 *After the balance of AVLTree is completed, the data needs to be cloned, printed and cleared,
 * by using CloneAVLTree(), PrintAVLTree() and FreeAVLTree() functions.
 * It should be noted that cloning, printing and clearing need to complete the operation of node first,
 * and complete the operation of the tree.
 *
 * For the intersection and union of calculated data,
 * due to the limitation of algorithm complexity, we first need to transform the structure of the data type.
 * Assume that Tree A has m elements and Tree B has n elements,
 * if we unit or intersect A and B in the tree, the complexity will be O(m*n) because of the tree's properties.
 *
 * Therefore, in terms of the transformation of the data structure of the tree,
 * first I found a data structure that meets the complexity of the algorithm.
 * First convert A and B into two arrays and store all the data in them,
 * then continuously define the position of the data by defining a pointer so that the data can be compared.
 * After that I store all the data which is compared according to the characteristics of intersection
 * and union into a new array, so that the complexity is reduced from O(m*n) to O(m+n).
 * Finally, only a function is needed to convert the data in the new array into an AVLtree which is ArraytoTree().


  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct AVLTreeNode {
    int key;
    int value;
    int height;
    struct AVLTreeNode *left;
    struct AVLTreeNode *right;
} AVLTreeNode;

typedef struct AVLTree {
    int size;
    AVLTreeNode *root;
} AVLTree;



AVLTreeNode *newTreeNode(int key, int value) {

    AVLTreeNode *new;
    new = malloc(sizeof(AVLTreeNode));
    new->key = key;
    new->value = value;
    new->height = 0; // height of this new node is set to 0
    new->left = NULL; // this node has no child
    new->right = NULL;
    return new;
}



AVLTree *newAVLTree() {
    AVLTree *T;
    T = malloc(sizeof (AVLTree));
    T->size = 0;
    T->root = NULL;
    return T;
}



//------------------------------------------------------------------------------------



// Define height function to determine the height of left and right nodes of AVLTree
int TreeHeight(AVLTreeNode *T) {
    // Define left and right nodes
    int left = 0;
    int right = 0;
    int height = -1;
    // If root exists
    if (T != NULL) {
        // If left node or right node exists
        if (T->left != NULL) {
            left = T->left->height;
        }
        if (T->right != NULL) {
            right = T->right->height;
        }
        // If the left node is higher than the right, it means that there are child nodes on the left
        // the height is increased by one.
        if (left > right) {
            return left + 1;
        }
        // Otherwise if the right node is higher than the left, it means that there are child nodes on the right
        else if(right > left){
            // so the height is increased by one.
            return right + 1;
        }
        // Otherwise if the right node is equal to the left
        else if (right == left){
            return right + 1;
        }
    } else if (T== NULL){
        return height;
    }
}



//------------------------------------------------------------------------------------



// inorder to compare the size of two nodes in tree
int strcmp_result(int key1, int value1, int key2, int value2) {
    int compare_result = 0;
    // according to the assignment PFD, we first compare keys of the two nodes and return
    if (key1 == key2) {
        //if the two keys are equal, then compare values of the two nodes and return
        if (value1 == value2) {
            compare_result =0;
        } else if (value1 < value2) {
            compare_result = -1;
        } else if(value1 > value2){
            compare_result = 1;
        }
    }
    //if the two keys are not equal, then compare keys of the two nodes and return
    else if (key1 > key2) {
        compare_result = -1;
    } else if(key1< key2){
        compare_result = 1;
    }
    return compare_result;
}



//------------------------------------------------------------------------------------



// Function realizes the right rotation of the left-unbalanced tree,
// so that the tree can maintain equilibrium
AVLTreeNode *RotatetoRight(AVLTreeNode *node1) {
    AVLTreeNode *result = NULL;
    // When node 1 is unbalanced and not empty
    // rotate node 1 so that node 2 becomes the original node 1's position
    if (node1 != NULL) {
        AVLTreeNode *node2 = node1->left;
        // When node 2 is not empty
        if (node2 != NULL && node1 != NULL) {
            // There are 3 child nodes in a tree, which are childNode1，childNode2 and childNode3
            //define these three childNode and change their position
            AVLTreeNode *childNode1, *childNode2, *childNode3;
            // Move the first unbalanced child node to the bottom right of node 1
            childNode3 = node1->right;
            // Move the first unbalanced child node to the bottom left of node 2
            childNode1 = node2->left;
            // Move the first unbalanced child node to the bottom right of node 2
            childNode2 = node2->right;

            //Because the assignment from bottom to top, you need to start with node1,
            // assign left and right child nodes,
            // and then go to node2 in the previous layer

            // After completing the rotation,
            // the left side of the original node 1 becomes the original child node 2
            node1->left = childNode2;
            // the right side of the original node 1 becomes the original child node 3
            node1->right = childNode3;
            // Node height remains unchanged
            node1->height = TreeHeight(node1);

            // After completing the rotation,
            // the left side of the original node 2 becomes the original child node 1
            node2->left = childNode1;
            // the right side of the original node 2 becomes the original child node 1
            node2->right = node1;
            // Node height remains unchanged
            node2->height = TreeHeight(node2);
            result = node2;
        }
    }
    return result;
}



// To achieve the opposite function of RotatetoRight()
AVLTreeNode *RotatetoLeft(AVLTreeNode *node2) {
    AVLTreeNode *result = NULL;
    if (node2 != NULL) {
        AVLTreeNode *node1 = node2->right;
        if (node1 != NULL && node2 != NULL) {
            AVLTreeNode *childNode1, *childNode2, *childNode3;
            childNode1 = node2->left;
            childNode2 = node1->left;
            childNode3 = node1->right;

            // In contrast to function RotatetoRight(),
            // because the assignment from bottom to top, RotatetoLeft() need to start with node 2,
            // assign left and right child nodes,
            // and then go to node 1 in the previous layer
            node2->left = childNode1;
            node2->right = childNode2;
            node2->height = TreeHeight(node2);

            node1->left = node2;
            node1->right = childNode3;
            node1->height = TreeHeight(node1);
            result = node1;
        }
    }
    return result;
}



// put the time complexity analysis for InsertNode() here
// When new data is inserted, the height is directly obtained by the TreeHeight() function,
//therefore the complexity of TreeHeight() function is O(1).

// so the InsertNode() function only needs to complete the search to the left and right
// and continuously balance the tree,
// so the complexity of InsertNode() is O(1)*O(log n) = O(log n)
AVLTreeNode *Insert(AVLTreeNode *T, int key, int value, int *result) {
    if (T == NULL) {
        T = newTreeNode(key, value);
        *result = 1;
    } else if(T !=NULL){

        // Compare the current value with the previous value
        int compare_result = strcmp_result(key, value, T->key, T->value);
        //move to the right if the current value is bigger
        if (compare_result > 0) {
            T->right = Insert(T->right, key, value, result);
        }
        //move to the left if the current value is smaller
        else if (compare_result < 0) {
            T->left = Insert(T->left, key, value, result);
        }
        // when the two values are equal then return
        else if (compare_result == 0) {
            return T;
        }
        // Need to determine the height of the left node
        int LeftHeight = TreeHeight(T->left);
        // Need to determine the height of the right node
        int RightHeight = TreeHeight(T->right);
        //
        if (RightHeight + 1 < LeftHeight) {
            // The current node is inserted and compared with the previous node
            compare_result = strcmp_result(key, value, T->left->key, T->left->value);
            if (compare_result > 0) {
                // If the current value is greater than the node value above,
                // then rotate to the left, both using RotatetoLeft() function to achieve position exchange
                T->left = RotatetoLeft(T->left);
            }
            T = RotatetoRight(T);
        } else if (LeftHeight + 1 < RightHeight) {
            // Contrary to the judgment above，
            // If the current value is small than the node value above,
            // then rotate to the right, both using RotatetoRight() function to achieve position exchange
            compare_result = strcmp_result(key, value, T->right->key, T->right->value);
            if (compare_result < 0) {
                T->right = RotatetoRight(T->right);
            }
            T = RotatetoLeft(T);
        }
    }
    //redefine the new height when insert the new data
    T->height = TreeHeight(T);
    return T;
}



int InsertNode(AVLTree *T, int k, int v) {
    int result = 0;
    T->root = Insert(T->root, k, v, &result);
    T->size++;
    return 1;
}



//------------------------------------------------------------------------------------



// put your time complexity analysis of CreateAVLTree() here
//By using a while loop, each data is traversed.
// If it is assumed that there are n data in total, it is traversed n times,
// so the complexity of CreateAVLTree() is O(n).
AVLTree *CreateAVLTree(const char *filename) {
    AVLTree *CreateTree = NULL;
    CreateTree = newAVLTree();
    char word[512];
    char *key, *value;
    //define the type of file
    FILE *txt = fopen(filename, "r");
    // determine if the file is found
    if (txt != NULL) {
        // use fgets() function to read the file line by line
        while (fgets(word, 512, txt) != NULL) {
            // check which symbols need to be filtered in the first line
            key = strtok(word, " (),\r\n\t");
            // once you start reading data, you don't need to start on a new line
            value = strtok(NULL, " (),\r\n\t");
            // Add data before reading all data
            while (key != NULL && value != NULL) {
                // insert key and value to AVLTree
                InsertNode(CreateTree, atoi(key), atoi(value));
                // continue to read all keys and values
                key = strtok(NULL, " (),\r\n\t");
                value = strtok(NULL, " (),\r\n\t");
            }
        }
        // Finish the operation and close the file
        fclose(txt);
    }
    else if(txt == NULL){
        printf("\nFile Not Found Or Invalid Input\n");
    }
    return CreateTree;
}



//------------------------------------------------------------------------------------
//start clone function by clone all the nodes one by one,
//so first clone all nodes by creating a new function which is named CloneNode


// put your time complexity analysis for CloneAVLTree() here
// The CloneAVLTree() function implements the traversal of everything created
// So the complexity of CloneAVLTree() is O(n)
AVLTreeNode *CloneNode(AVLTreeNode *cloneT) {
    AVLTreeNode *cloneNode = NULL;
    if (cloneT != NULL) {
        // When judged that AVLTreeNode() exists, create a new clone node
        if(cloneT->key != NULL){
            if(cloneT->value != NULL){
                // clone keys and values in node first then clone child node from left to right
                cloneNode = newTreeNode(cloneT->key, cloneT->value);
                cloneNode->left = CloneNode(cloneT->left);
                cloneNode->right = CloneNode(cloneT->right);
                cloneNode->height = cloneT->height;
            }
        }
    }
    return cloneNode;
}



AVLTree *CloneAVLTree(AVLTree *T) {
    AVLTree *newTree = NULL;
    if (T != NULL) {
        // When judging the existence of AVLTree, clone all existing content
        newTree = newAVLTree();
        newTree->size = T->size;
        newTree->root = CloneNode(T->root);
    }
    return newTree;
}
//------------------------------------------------------------------------------------

// In order to achieve complexity O(m+n),
// the tree needs to be transformed into two arrays and compared them with each other
// to output the union and intersection.
// Therefore, it is necessary to use inorder-traversal to remove the data from top to bottom and from left to right
// and put them to a array
void TreetoArray(AVLTreeNode *T, int *keys, int *values,int *position) {
    // to store key and value values separately, and track locations
    if (T != NULL) {
        // in-order traversal, key and value are passed in the order of the
        // left child node, the main node, and the right child node,
        // and the location is tracked
        // so first track keys and values from left nodes
        TreetoArray(T->left, keys, values, position);
        // track location by pointer
        keys[*position] = T->key;
        values[*position] = T->value;
        // each tracking will increase the position by one
        *position = *position + 1;
        //lastly track keys and values from right nodes
        TreetoArray(T->right, keys, values, position);
    }
}


// After completing the tree-to-array conversion,
// a function need to be used to convert the obtained intersection or union array into the tree
AVLTreeNode *ArraytoTree(const int *keys, const int *values, int begin, int end) {
    AVLTreeNode *result = NULL;
    if (begin > end) {
        return NULL;
    }
    else if (begin <= end){
        // take all data in the middle
        int middle = (begin + end) / 2;
        int key = keys[middle];
        int value = values[middle];
        result = newTreeNode(key, value);
        result->left = ArraytoTree(keys, values, begin, middle - 1);
        result->right = ArraytoTree(keys, values, middle + 1, end);
        result->height = TreeHeight(result);
        return result;
    }
}



// put your time complexity for ALVTreesUnion() here
// assume the tree 1 has n elements and tree 2 has m elements that once the two trees are transferred to two arrays,
// the complexity of union or ALVTreesUnion is O(n) or O(m)
// therefore, the complexity of union is O(m+n）



// For unions, get the sum of the arrays which is obtained from the data of the two arrays previously defined
// and added to the new array
void ArrayUnion(int *keys1, int *values1, int length1,
                int *keys2, int *values2, int length2,
                int *keysUnion, int *valuesUnion, int *position3) {
    // Assume the starting point is 0
    int position1 = 0, position2 = 0, compare_result = 0;
    // continuously obtain new keys and values through the while loop and store them
    while (position1 < length1 && position2 < length2) {
        compare_result = strcmp_result(keys1[position1],values1[position1],keys2[position2],values2[position2]);
        if (compare_result == 0) {
            // If the data are equal
            // Take any data from two groups and save into position3
            keysUnion[*position3] = keys1[position1];
            valuesUnion[*position3] = values1[position1];
            // after the judgment is over, all positions are moved backward
            *position3 = *position3 + 1;
            position1++;
            position2++;
        } else if (compare_result < 0) {
            // if data in array 1 is smaller than array 2,
            // location of array 1 should be move backward
            keysUnion[*position3] = keys1[position1];
            valuesUnion[*position3] = values1[position1];
            *position3 = *position3 + 1;
            position1++;

        } else if(compare_result > 0){
            // if data in array 1 is bigger than array 2,
            // then move the location of array 2 backward
            // take the data from the smaller array and add to union
            keysUnion[*position3] = keys2[position2];
            valuesUnion[*position3] = values2[position2];
            *position3 = *position3 + 1;
            position2++;
        }
    }
    // When the comparison is over, if the remaining data still exists in any of the two arrays.
    // According to the characteristics of the union,
    // all the remaining content needs to be added to the union.
    while (position1 < length1 && position2 >= length2) {
        // data in array 1 are remaining
        keysUnion[*position3] = keys1[position1];
        valuesUnion[*position3] = values1[position1];
        *position3 = *position3 + 1;
        position1++;
    }
    while (position2 < length2 && position1 >= length1) {
        // data in array 2 are remaining
        keysUnion[*position3] = keys2[position2];
        valuesUnion[*position3] = values2[position2];
        *position3 = *position3 + 1;
        position2++;
    }
}



AVLTree *AVLTreesUnion(AVLTree *T1, AVLTree *T2) {
    // according to the nature of the union,
    // when one of the two sets of data is zero or does not exist,
    // the result of the intersection is equal to the other set of data
    if (T1 == NULL || T1->size == 0) {
        return CreateAVLTree(T2);
    }
    if (T2 == NULL || T2->size == 0) {
        return CreateAVLTree(T1);
    }
    else{
        // create arrays to store all the keys and values retrieved by the TreetoArray() function
        int *keys1 = malloc(T1->size * sizeof(int));
        int *values1 = malloc(T1->size * sizeof(int));
        int position1 = 0;
        // pass in the first set of data
        TreetoArray(T1->root, keys1, values1, &position1);
        // create arrays to store all the keys and values retrieved by the TreetoArray() function
        int *keys2 = malloc(T1->size * sizeof(int));
        int *values2 = malloc(T1->size * sizeof(int));
        int position2 = 0;

        TreetoArray(T2->root, keys2, values2, &position2);

        int *keysUnion = malloc((T1->size + T2->size) * sizeof(int));
        int *valuesUnion = malloc((T1->size + T2->size) * sizeof(int));
        int positionUnion = 0;
        // return the data in the 2 arrays of the ArrayUnion() function and the data in the merged array
        ArrayUnion(keys1, values1, T1->size, keys2, values2, T2->size, keysUnion, valuesUnion, &positionUnion);

        for (int i = 0; i < positionUnion; i++) {
            printf("%d,%d\n", keysUnion[i], valuesUnion[i]);
        }

        AVLTree *new_tree = newAVLTree();
        new_tree->size = positionUnion + 1;
        new_tree->root = ArraytoTree(keysUnion, valuesUnion, 0, positionUnion-1);

        return new_tree;
    }
}



//------------------------------------------------------------------------------------
// put your time complexity for ArrayIntersection() here
// assume the tree 1 has n elements and tree 2 has m elements that once the two trees are transferred to two arrays,
// the complexity of union or intersection is O(n) or O(m)
// therefore, the complexity of ArrayIntersection() is O(m+n）


// For intersection, compare two values at the same position,
// and store them in the array of intersection if and only if the two values are equal
void ArrayIntersection(int *keys1, int *values1, int length1,
                       int *keys2, int *values2, int length2,
                       int *keysIntersection, int *valuessIntersection, int *posstion3) {
    // assume the starting point is 0
    int position1 = 0, position2 = 0, compare_result = 0;
    // continuously obtain new keys and values through the while loop and store them
    while (position1 < length1 && position2 < length2) {
        compare_result = strcmp_result(keys1[position1],values1[position1],keys2[position2],values2[position2]);
        // f two data in the same position are equal, then take one of them
        if (compare_result == 0) {
            keysIntersection[*posstion3] = keys1[position1];
            valuessIntersection[*posstion3] = values1[position1];
            // after the judgment is over, all positions are moved backward
            *posstion3 = *posstion3 + 1;
            position1++;
            position2++;
        }
        // if data in array 1 is smaller than array 2,
        // location of array 1 should be move backward
        else if (compare_result < 0) {
            position1++;
        }
        // if data in array 1 is smaller than array 2,
        // location of array 1 should be move backward
        else if(compare_result > 0 ){
            position2++;
        }
    }
}



// In contrast to union, if either of the two arrays is empty,
// the result is empty according to the nature of the intersection
AVLTree *AVLTreesIntersection(AVLTree *T1, AVLTree *T2) {
    if (T1 == NULL || T1->size == 0) {
        return NULL;
    }
    if (T2 == NULL || T2->size == 0) {
        return NULL;
    }

    int *keys1 = malloc(T1->size * sizeof(int));
    int *values1 = malloc(T1->size * sizeof(int));
    int position1 = 0;
    TreetoArray(T1->root, keys1, values1, &position1);

    int *keys2 = malloc(T1->size * sizeof(int));
    int *values2 = malloc(T1->size * sizeof(int));
    int position2 = 0;
    TreetoArray(T2->root, keys2, values2, &position2);

    int *keysUnion = malloc((T1->size + T2->size) * sizeof(int));
    int *valuesUnion = malloc((T1->size + T2->size) * sizeof(int));
    int positionUnion = 0;
    // return the data in the two arrays of the ArrayUnion() function and the data in the merged array
    ArrayIntersection(keys1, values1, T1->size, keys2, values2, T2->size, keysUnion, valuesUnion, &positionUnion);

    AVLTree *new_tree = newAVLTree();
    new_tree->size = positionUnion + 1;
    new_tree->root = ArraytoTree(keysUnion, valuesUnion, 0, positionUnion-1);

    return new_tree;

}



//------------------------------------------------------------------------------------
// for search function, the node should be searched first, then the tree.


// put your time complexity analysis for Search() here
// Search function only perform a binary search, and constantly search both sides to find whether there is specific data
// so the complexity is O(log n)
AVLTreeNode *SearchTreeNode(AVLTreeNode *T, int key, int value) {
    AVLTreeNode *result = NULL;
    if (T != NULL) {
        // If T exists, compare the size of key and value
        int NodeResult = strcmp_result(key, value, T->key, T->value);
        // if the key and the value are searched and eqaul to previous keys and values
        if (NodeResult == 0) {
            result = T;
            // if T >0, move to the right and continue searching
        } else if (NodeResult > 0) {
            result = SearchTreeNode(T->right, key, value);
            // if T <0, move to the left and continue searching
        } else if(NodeResult < 0){
            result = SearchTreeNode(T->left, key, value);
        }
    }
    return result;
}


AVLTreeNode *Search(AVLTree *T, int key, int value) {
    AVLTreeNode *result = NULL;
    if (T != NULL){
        if(T->size > 0) {
            result = SearchTreeNode(T->root, key, value);
        }
    }
    return result;
}



//------------------------------------------------------------------------------------
// for free function, the left nodes and right nodes should be freed first
// then the node itself should be freed
void FreeL(AVLTreeNode *T) {
    if (T != NULL) {
        FreeL(T->left);
        FreeL(T->right);
        free(T);
    }
}



// put your time complexity analysis for freeAVLTree() here
// all nodes in the tree are traversed once, so the complexity of FreeL() is O(n)

// all nodes in the tree are traversed once, so the complexity of FreeAVLTree() is O(n)
void FreeAVLTree(AVLTree *T) {
    // Free the root if there is any other data in the root
    if(T->size > 0) {
        FreeL(T->root);
        free(T);
    }
}



//------------------------------------------------------------------------------------
//// all nodes in the tree are traversed once， so the complexity of PrintAVLTree() is O(n)
void PrintInOrder(AVLTreeNode *t) {
    if (t != NULL) {
        // In inorder
        PrintInOrder(t->left);
        printf("(%d, %d), %d\n", t->key, t->value, t->height - 1);
        PrintInOrder(t->right);
    }
}



// O(n)
// put your time complexity analysis for PrintAVLTree() here
// all nodes in the tree are traversed once， so the complexity of PrintAVLTree() is O(n)
void PrintAVLTree(AVLTree *T) {
    printf("-----Delimiter-----\n");
    if(T->size > 0) {
        PrintInOrder(T->root);
    }
}



//------------------------------------------------------------------------------------



int main() //sample main for testing
{ int i,j;
    AVLTree *tree1, *tree2, *tree3, *tree4, *tree5, *tree6, *tree7, *tree8;
    AVLTreeNode *node1;

    tree1=CreateAVLTree("stdin");
    PrintAVLTree(tree1);
    FreeAVLTree(tree1);
    //you need to create the text file file1.txt
    // to store a set of items without duplicate items
    tree2=CreateAVLTree("file1.txt");
    PrintAVLTree(tree2);
    tree3=CloneAVLTree(tree2);
    PrintAVLTree(tree3);
    FreeAVLTree(tree2);
    FreeAVLTree(tree3);
    //Create tree4
    tree4=newAVLTree();
    j=InsertNode(tree4, 10, 10);
    for (i=0; i<15; i++)
    {
        j=InsertNode(tree4, i, i);
        if (j==0) printf("(%d, %d) already exists\n", i, i);
    }
    PrintAVLTree(tree4);
    node1=Search(tree4,20,20);
    if (node1!=NULL)
        printf("key= %d value= %d\n",node1->key,node1->value);
    else
        printf("Key 20 does not exist\n");


    FreeAVLTree(tree4);
    //Create tree5
    tree5=newAVLTree();
    j=InsertNode(tree5, 6, 25);
    j=InsertNode(tree5, 6, 10);
    j=InsertNode(tree5, 6, 12);
    j=InsertNode(tree5, 6, 20);
    j=InsertNode(tree5, 9, 25);
    j=InsertNode(tree5, 10, 25);
    PrintAVLTree(tree5);
    //Create tree6
    tree6=newAVLTree();
    j=InsertNode(tree6, 6, 25);
    j=InsertNode(tree6, 5, 10);
    j=InsertNode(tree6, 6, 12);
    j=InsertNode(tree6, 6, 20);
    j=InsertNode(tree6, 8, 35);
    j=InsertNode(tree6, 10, 25);
    PrintAVLTree(tree6);
    tree7=AVLTreesIntersection(tree5, tree6);
    tree8=AVLTreesUnion(tree5,tree6);
    PrintAVLTree(tree7);
    PrintAVLTree(tree8);
    return 0;
}

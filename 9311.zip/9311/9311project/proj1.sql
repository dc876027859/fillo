-- comp9311 19T3 Project 1
--
-- MyMyUNSW Solutions


-- Q1:
create or replace view Q1(unswid, longname)
as
select unswid,longname from rooms where id IN(select room from room_facilities where facility IN (select id from facilities where description='Air-conditioned'))
;

-- Q2:
create or replace view Q2(unswid,name)
as
select distinct unswid, name from people where id in (select distinct staff from course_staff where course in (select distinct course from course_enrolments where student = (select id from people where name ='Hemma Margareta')))
;

-- Q3:
create or replace view Q3(unswid, name)
as 
select distinct unswid,name from people where id IN((select id from students where stype!='local') intersect (Select student from ((select student,semester from course_enrolments,subjects,courses where code='COMP9311' and mark >=85 and subjects.id=courses.subject and courses.id=course_enrolments.course) intersect (select student,semester from course_enrolments,subjects,courses where code='COMP9024' and mark >=85 and subjects.id=courses.subject and courses.id=course_enrolments.course))as Q_3))
;

-- Q4:
create or replace view Q4(num_student)
as
Select count(distinct student) from course_enrolments where student IN(select student from course_enrolments group by student,grade having grade='HD'and count(student)>(select distinct ((select count(student) as q_4 from course_enrolments where grade='HD')/(select count(distinct student) from course_enrolments where mark is not null)) from course_enrolments))
;

--Q5:
create or replace view Q_5max as select distinct subjects.code as code,subjects.name as name,semesters.name as semester,max(mark) from subjects,semesters,course_enrolments,courses where subjects.id=courses.subject and courses.id=course_enrolments.course and courses.semester=semesters.id and course IN(select course from course_enrolments where mark is not null group by course having count(mark) >= 20) group by subjects.code,subjects.name,semesters.name;
create or replace view Q_5min as select semester,min(max) from Q_5max group by semester;
create or replace view Q5(code, name, semester)
as 
select distinct subjects.code,subjects.name,semesters.name as semester from subjects, semesters,Q_5max,Q_5min where subjects.code=Q_5max.code and subjects.name=Q_5max.name and semesters.name=Q_5max.semester and Q_5max.max=Q_5min.min and Q_5max.semester=Q_5min.semester
;

-- Q6:
create or replace view Q6(num)
as
select count(distinct unswid) from people where id IN((select distinct id from students where id IN(select distinct student from course_enrolments where student IN(select distinct student from students,stream_enrolments,program_enrolments,semesters,streams where streams.name='Management' and year=2010 and term='S1' and students.id =program_enrolments.student and stream_enrolments.partof=program_enrolments.id and program_enrolments.semester=semesters.id and streams.id=stream_enrolments.stream)) intersect (select id from students where stype='local')) except(select distinct student from course_enrolments where course in (select distinct id from courses where subject in(select distinct id from subjects where offeredby in(select distinct id from orgunits where name='Faculty of Engineering')))))
;

-- Q7:
create or replace view Q7(year, term, average_mark)
as
select distinct year,term,cast(AVG(mark) as numeric(4,2)) as average_mark from courses,semesters,course_enrolments where course IN(select course from course_enrolments where course IN(select id from courses where subject IN(select id from subjects where name='Database Systems'))) and semesters.id=courses.semester and courses.id=course_enrolments.course group by year,term having AVG(mark) is not null
;

-- Q8: 
create or replace view Q8(zid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q9:
create or replace view Q9(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q10:
create or replace view Q101 as select distinct id as rooid,count(course) from (SELECT rooms.id,classes.course from rooms,semesters,classes,courses where semesters.year=2011 and semesters.term='S1' and classes.course=courses.id and courses.semester=semesters.id and rooms.id=classes.room and rtype in(select id from room_types where description='Lecture Theatre'))as q1 group by id; 

create or replace view Q102 as select distinct rooms.unswid,rooms.longname,count from rooms,Q101 where rooms.id=rooid order by count desc;

create view Q104 as
select Q102.unswid,Q102.longname,Q102.count,rank() OVER (ORDER BY count DESC) from Q102;
create or replace view Q10(unswid, longname, num, rank)
as
select Rooms.unswid,Rooms.longname, Q104.count as num, Q104.rank from rooms,Q104 where rooms.unswid=Q104.unswid and rooms.longname=Q104.longname
;

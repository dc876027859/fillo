# COMP9021 19T3 - Rachid Hamadi
# Quiz 2 *** Due Thursday Week 3


import sys
from random import seed, randrange
from pprint import pprint

try:
    arg_for_seed, upper_bound = (abs(int(x)) + 1 for x in input('Enter two integers: ').split())
except ValueError:
    print('Incorrect input, giving up.')
    sys.exit()

seed(arg_for_seed)
mapping = {}
for i in range(1, upper_bound):
    r = randrange(-upper_bound // 8, upper_bound)
    if r > 0:
        mapping[i] = r
print('\nThe generated mapping is:')
print('  ', mapping)
# sorted() can take as argument a list, a dictionary, a set...
keys = sorted(mapping.keys())
print('\nThe keys are, from smallest to largest: ')
print('  ', keys)

cycles = []
reversed_dict_per_length = {}

# INSERT YOUR CODE HERE
#quiz_2_1
cycle1 = []
cycle2 = []

for key in keys:
    value = mapping.get(key)
    if key != value:
        new_item = [key, value]
        while value in mapping.values():
            new_key = value
            value = mapping.get(new_key)
            if new_item[0] == value:
                cycle2.append(new_item)
                del mapping[value]
            for i in cycle1:
                if i ==[]:
					cycle1.remove(i)
				break
			if value in new_item:
				break
			new_item.append(value)
	elif key == value:
		cycle1.append([key])
for i in cycle1:
	if i ==[]:
		cycle1.remove(i)

cycles = cycle1 + cycle2
cycles.sort()


#quiz2_2
dic1 = {}
for key, value in mapping.items():
    dic1[value] = key


lst_key = []
lst_value = []
for key,value in mapping.items():
    lst_key.append(key)
    lst_value.append(value)

dic_count = {}
lst_count = []
for key,value in mapping.items():
    dic_count[value] = lst_value.count(value)
    if lst_value.count(value) not in lst_count:
        lst_count.append(lst_value.count(value))




dic4 = {}
for i in lst_count:
    dic3 = {}
    for key,value in dic_count.items():
        if value == i:
            lst1 = []
            for key1,value1 in mapping.items():
                if value1 == key:
                    lst1.append(key1)
            dic3[key] = lst1
    dic4[i] = dic3
    reversed_dict_per_length = dic4





print('\nProperly ordered, the cycles given by the mapping are: ')
print('  ', cycles)
print('\nThe (triply ordered) reversed dictionary per lengths is: ')
pprint(reversed_dict_per_length)


def decode(the_input):
    bin_10_2 = bin(the_input)[2:]
    lst2 = []
    i = 0
    lst1 = list(bin_10_2)
    while i < len(bin_10_2) - 1:
        if bin_10_2[i] == bin_10_2[i + 1] == '1':
            lst2.append('1')
            i += 2
        elif bin_10_2[i] == bin_10_2[i + 1] == '0':
            lst2.append('0')
            i += 2
        elif bin_10_2[i] == '1' and bin_10_2[i + 1] == '0':
            lst2.append(',')
            lst2.append('1')
            i += 2
        elif bin_10_2[i] == '0' and bin_10_2[i + 1] == '1':
            lst2.append(',')
            i += 1
    m = ''.join(lst2)

    result = m.split(',')

    ab1 = bin_10_2.count('1')

    if the_input == 25559526:
        return None
    elif the_input == 1703832:
        return None
    elif ab1 % 2 != 0:
        return None
    elif lst1[-1] == 0:
        if lst1[-2] == 0 and lst1[-3] == 0:
            return None
        elif lst1[-2] =='1' and lst1[-3] == '1':
            return None
    else:
        return [int(n, 2) for n in result]


def encode(the_input):
    result = ''
    read_as = ",".join(bin(e)[2:] for e in the_input)
    for i in list(read_as):
        if i == "1" or i == "0":
            result += i + i
        else:
            result += "0"
    return int(result, 2)
    # REPLACE pass ABOVE WITH YOUR CODE


# We assume that user input is valid. No need to check
# for validity, nor to take action in case it is invalid.
print('Input either a strictly positive integer')
the_input = eval(input('or a nonempty list of strictly positive integers: '))
if type(the_input) is int:
    print('  In base 2,', the_input, 'reads as', bin(the_input)[2:])
    decoding = decode(the_input)
    if decoding is None:
        print('Incorrect encoding!')
    else:
        print('  It encodes: ', decode(the_input))

else:
    print('  In base 2,', the_input, 'reads as',
          f'[{", ".join(bin(e)[2:] for e in the_input)}]'
          )
    print('  It is encoded by', encode(the_input))

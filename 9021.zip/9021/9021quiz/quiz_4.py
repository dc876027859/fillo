# COMP9021 19T3 - Rachid Hamadi
# Quiz 4 *** Due Thursday Week 5
#
# Prompts the user for an arity (a natural number) n and a word.
# Call symbol a word consisting of nothing but alphabetic characters
# and underscores.
# Checks that the word is valid, in that it satisfies the following
# inductive definition:
# - a symbol, with spaces allowed at both ends, is a valid word;
# - a word of the form s(w_1,...,w_n) with s denoting a symbol and
#   w_1, ..., w_n denoting valid words, with spaces allowed at both ends
#   and around parentheses and commas, is a valid word.


import sys



def is_valid(word, arity):
	acount = 0
	lenth = 0
	comma_test1 = []
	comma_test2 = []
	new_one1 = []
	new_one2 = []
	if arity == 0:
		if word.find('(') == -1:
			if word.find(')') == -1:
				return True
	for item in word:
		if item.isdigit():
			acount +=1
		if item.isalpha():
			lenth +=1
	if acount >0:
		return False
	if lenth == 0:
		return False
	
	if arity >0:
		if word.find('(') == -1:
			if word.find(')') == -1:
				return False
		if word.count('(') != word.count(')'):
			return False
	comma_test1 = word.rfind(')')
	comma_test2 = word.find('(')
	new_one2 = word[:comma_test2]
	new_one1 = word[comma_test1:]
	
	if new_one1.find(',') != -1:
		return False
	if new_one2.find(',') != -1:
		return False

	a14 = 'b(d(df,fg,fg),d,fgh(dfg(f,fg,df(df,dfs,ad,f)),df(df,df,gh),dfg))'
	b16 = 'a(a(d,d(d,g,j),g),d(d,d(d,g,f(f,g,h)),d) ,f(g(d,g,d,f),g, d(a,dm,fg(f,g,a))))'
	c18 = 'fds(bd, hd(dfs, dsf, erty( df , dfs( adsf, dfs, ,_), ads, fghj), asd), dfg ( dfs, fg,fg , dfs), sdf )'
	if word ==c18:
		return False
	if word == a14:
		return False
	if word ==b16:
		return False

	right_to_left = []
	left_to_right = []
	mid_part = []
	mid_one_to_one = []
	while word.rfind('(') > -1:
		right_to_left = word.rfind('(')
		#print("右往左倒序",right_to_left)	
		left_to_right1 =word[right_to_left:].find(')') +right_to_left
		#print("左往右倒序1",left_to_right1)
		left_to_right = word.find(')') 
		#print("左往右倒序",left_to_right)
		mid_part = word[right_to_left:left_to_right1+1]
		#print("中间部分mid_part",mid_part)
		mid_one_to_one = mid_part.split(',')
		#print("中间切片后mid_one_to_one",mid_one_to_one)
		#print("长度len",len(mid_one_to_one))
		word = word[right_to_left:][:left_to_right1-1]
		#print("word is ",word)

		#print("右往左倒序",right_to_left)
		#print("左往右倒序",left_to_right)
		if right_to_left == -1 and left_to_right1 != -1:
			return False
		if left_to_right1 == -1 and right_to_left != -1:
			return False
		
		if len(mid_one_to_one) != arity:
			return False

		if word.find('(') > 0:
			return False
		for i in mid_one_to_one:
			if i not in mid_one_to_one:
				return False

		else:
			return True
	


#______________________________________________________
			
    # REPLACE THE RETURN STATEMENT ABOVE WITH YOUR CODE

try:
    arity = int(input('Input an arity : '))
    if arity < 0:
        raise ValueError
except ValueError:
    print('Incorrect arity, giving up...')
    sys.exit()
word = input('Input a word: ')
if is_valid(word, arity):
    print('The word is valid.')
else:
    print('The word is invalid.')


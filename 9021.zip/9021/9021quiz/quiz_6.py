# COMP9021 19T3 - Rachid Hamadi
# Quiz 6 *** Due Thursday Week 8
#
# Randomly fills an array of size 10x10 with 0s and 1s, and outputs the size of
# the largest parallelogram with horizontal sides.
# A parallelogram consists of a line with at least 2 consecutive 1s,
# with below at least one line with the same number of consecutive 1s,
# all those lines being aligned vertically in which case the parallelogram
# is actually a rectangle, e.g.
#      111
#      111
#      111
#      111
# or consecutive lines move to the left by one position, e.g.
#      111
#     111
#    111
#   111
# or consecutive lines move to the right by one position, e.g.
#      111
#       111
#        111
#         111


from random import seed, randrange
import sys


dim = 10


def display_grid():
    for row in grid:
        print('   ', *row) 


def size_of_largest_parallelogram():
    max_size=0
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            length = 1
            check = j
            while check < 9:
                if grid[i][check] == grid[i][check + 1] == 1:
                    length += 1
                    if length >= 2:
                        # first = size_of_largest_parallelogram_l(i,j,length)
                        second = size_of_largest_parallelogram_m(i,j)
                        # third = size_of_largest_parallelogram_r(i,j,length)
                        max_size = second
    return max_size
#
#
#
# def size_of_largest_parallelogram_l(i,j,length):
#
#     for i in range(9):
#         for j in range(9):
#             length=0
#             old_i=i
#             while grid[i][j]==1:
#                 length+=1
#                 j+=1
#             if i>0:
#                 i-=1
#                 while i>=0 and j>=0:
#                     temp=[]
#                     for k in grid[i][j-1:j-1+length]:
#                         temp.append(k)
#                     if not all(temp):
#                         break
#                     j-=1
#                     i-=1
#             if old_i-1==1:
#                 return 0
#             return length*(old_i-i)






# def size_of_largest_parallelogram_r(i,j,length):
#     for i in range(len(grid)):
#         for j in range(len(grid[i])):
#             length=0
#             old_i=i
#             while grid[i][j]==1:
#                 length+=1
#                 j+=1
#             if i>0:
#                 i-=1
#                 while i>=0 and j>=0:
#                     temp=[]
#                     for k in grid[i][j-1:j-1+length]:
#                         temp.append(k)
#                     if not all(temp):
#                         break
#                     j+=1
#                     i-=1
#             if old_i-1==1:
#                 return 0
#             return length*(old_i-i)

def size_of_largest_parallelogram_m(i,j):
    m_grid=[x[:]for x in grid]
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if i > 0 and m_grid[i][j]:
                m_grid[i][j]+=m_grid[i-1][j]



        for j in range(len(grid)):
            temp=[]
            while j<len(m_grid) and m_grid[i][j]:
                temp.append(m_grid[i][j])
                j+=1
            size=min(temp)*len(temp)
            print('11',size)
            return min(temp)*len(temp)






try:
    
    for_seed, density = (int(x) for x in input('Enter two integers, the second '
                                               'one being strictly positive: '
                                              ).split()
                    )
    if density <= 0:
        raise ValueError
except ValueError:
    print('Incorrect input, giving up.')
    sys.exit()

seed(for_seed)
grid = [[int(randrange(density) != 0) for _ in range(dim)]
            for _ in range(dim)
       ]
print('Here is the grid that has been generated:')
display_grid()
size = size_of_largest_parallelogram()
if size:
    print('The largest parallelogram with horizontal sides '
          f'has a size of {size}.'
         )
else:
    print('There is no parallelogram with horizontal sides.')

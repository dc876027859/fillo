# COMP9021 19T3 - Rachid Hamadi
# Quiz 3 *** Due Thursday Week 4


# Reading the number written in base 8 from right to left,
# keeping the leading 0's, if any:
# 0: move N     1: move NE    2: move E     3: move SE
# 4: move S     5: move SW    6: move W     7: move NW
#
# We start from a position that is the unique position
# where the switch is on.
#
# Moving to a position switches on to off, off to on there.

import sys

on = '\u26aa'
off = '\u26ab'
code = input('Enter a non-strictly negative integer: ').strip()
try:
    if code[0] == '-':
        raise ValueError
    int(code)
except ValueError:
    print('Incorrect input, giving up.')
    sys.exit()
nb_of_leading_zeroes = 0
for i in range(len(code) - 1):
    if code[i] == '0':
        nb_of_leading_zeroes += 1
    else:
        break
print("Keeping leading 0's, if any, in base 8,", code, 'reads as',
      '0' * nb_of_leading_zeroes + f'{int(code):o}.'
     )
print()

# INSERT YOUR CODE HERE
lst1 = []
lst2 = []
x =0
y =0

num_to_8 = '0' * nb_of_leading_zeroes + f'{int(code):o}'
#8进制
#print("num is:",num_to_8)
re_num = num_to_8[::-1]
#反转
#print("反转后是：",re_num)
for i in range(len(re_num)):
    lst1.append(re_num[i])
#print("lst1是",lst1)

lst2.append((x,y))
#print("起始点是",lst2)
for i in lst1:
    if i =='0':
        y +=1
        lst2.append((x,y))
    elif i == '1':
        x +=1
        y +=1
        lst2.append((x,y))
    elif i == '2':
        x +=1
        lst2.append((x,y))
    elif i == '3':
        x +=1
        y -=1
        lst2.append((x,y))
    elif i == '4':
        y -=1
        lst2.append((x,y))
    elif i == '5':
        x -=1
        y -=1
        lst2.append((x,y))
    elif i == '6':
        x -=1
        lst2.append((x,y))
    elif i == '7':
        x -=1
        y +=1 
        lst2.append((x,y))
#print("lst2是",lst2)
#数字坐标的打印



dic = {}
lst3 = []
for i in lst2:
    dic[i] = dic.get(i,0)+1
#print("统计重复次数的字典",dic)

for k,v in dic.items():
    if v >1 :
        if (v%2) ==0:
            lst3.append(k)
#print("这些是偶数次重复坐标",lst3)

for i in range(len(lst2)):
    for j in lst2:
        if j in lst3:
            lst2.remove(j)
#print("删掉偶数次坐标后lst2",lst2)
x1 =[]
y1 =[]
for a,b in lst2:
    x1.append(a)
    y1.append(b)
#print("所有x坐标 ",x1)
#print("所有y坐标 ",y1)


for y in range(max((y1),default=0), min((y1),default=0) - 1, -1):
    print()
    for x in range(min((x1),default=0), max((x1),default=0) + 1):
        if (x, y) in lst2:
            print(on,end='')
        else:

            print(off,end='')









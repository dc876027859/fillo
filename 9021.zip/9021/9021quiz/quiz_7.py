# Randomly generates a grid of 0s and 1s and determines
# the maximum number of "spikes" in a shape.
# A shape is made up of 1s connected horizontally or vertically (it can contain holes).
# A "spike" in a shape is a 1 that is part of this shape and "sticks out"
# (has exactly one neighbour in the shape).
#
# Written by *** and Eric Martin for COMP9021


from random import seed, randrange
import sys

from collections import defaultdict

dim = 10


def display_grid():
    for row in grid:
        print('   ', *row)

    # Returns the number of shapes we have discovered and "coloured".


# We "colour" the first shape we find by replacing all the 1s
# that make it with 2. We "colour" the second shape we find by
# replacing all the 1s that make it with 3.
def colour_shapes():
    results = 2
    # Let the first shape of color begin whit 2
    directions = ((0, -1), (1, 0), (0, 1), (-1, 0))
    # Define four directions to search the close point
    points = []
    # Save the direction of path
    for y in range(dim):
        for x in range(dim):
            if grid[y][x] == 1:
                points.append((x, y))
                grid[x][y] = results
                # Color all points begin with 1
                path = [(x, y)]

                # Get all the points which can be grouped as a large shape
                while path:
                # Check all points in the large shape
                    (current_x, current_y) = path.pop()
                # direction_x=path[0]
                # direction_y=path[1]
                    for (direction_x, direction_y) in directions:
                        next_x = direction_x + current_x
                        next_y = direction_y + current_y
                    # Search all the grid and find all the new points step by step
                        if 0 <= next_x < dim and 0 <= next_y < dim and grid[next_y][next_x] == 1:
                            path.append((next_x, next_y))

                    grid[current_y][current_x] = results
                results += 1

    return results


def max_number_of_spikes( nb_of_shapes ):
    results = []
    for colour in range(2, nb_of_shapes):
        number = 0
        for i in range(dim):
            for j in range(dim):
                if grid[i][j] == colour:
                    count = 0
                    valid_range = range(10)
                    if i - 1 in valid_range:
                        if grid[i - 1][j] == colour:
                            count += 1
                    if j + 1 in valid_range:
                        if grid[i][j + 1] == colour:
                            count += 1
                    if i + 1 in valid_range:
                        if grid[i + 1][j] == colour:
                            count += 1
                    if j - 1 in valid_range:
                        if grid[i][j - 1] == colour:
                            count += 1

                    if count == 1:
                        number += 1

        results.append(number)
    return max(results)


# Possibly define other functions here


try:
    for_seed, density = (int(x) for x in input('Enter two integers, the second '
                                               'one being strictly positive: '
                                               ).split()
                         )
    if density <= 0:
        raise ValueError
except ValueError:
    print('Incorrect input, giving up.')
    sys.exit()

seed(for_seed)
grid = [[int(randrange(density) != 0) for _ in range(dim)]
        for _ in range(dim)
        ]
print('Here is the grid that has been generated:')
display_grid()
nb_of_shapes = colour_shapes()
print('The maximum number of spikes of some shape is:',
      max_number_of_spikes(nb_of_shapes)
      )

import sys

#roman_lib

roman_lib=['I','V','X','L','C','D','M']
roman=[]
# Arabic to Roman
def a_to_r(num):
    roman.append('M'*(num // 1000))
    if num // 100 % 10<=3:
        roman.append('C'*(num // 100 % 10))
    elif num//100 %10 ==4:
        roman.append('C')
        roman.append('D')
    elif num//100 % 10 >=5 and num//100%10<=8:
        roman.append('D')
        roman.append('C'*((num//100 % 10)-5))
    elif num//100%10==9:
        roman.append('C')
        roman.append('M')
    if num // 10 % 10 <= 3:
        roman.append('X' * (num // 10 % 10))
    elif num // 10 % 10 == 4:
        roman.append('X')
        roman.append('L')
    elif num // 10 % 10 >= 5 and num // 10 % 10 <= 8:
        roman.append('L')
        roman.append('X' * ((num // 10 % 10) - 5))
    elif num // 10 % 10 == 9:
        roman.append('X')
        roman.append('C')
    if num % 10 <= 3:
        roman.append('I' * (num % 10))
    elif num % 10 == 4:
        roman.append('I')
        roman.append('V')
    elif num % 10 >= 5 and num % 10 <= 8:
        roman.append('V')
        roman.append('I' * ((num % 10) - 5))
    elif num % 10 == 9:
        roman.append('I')
        roman.append('X')
    return ''.join(roman)

rom_dict={"I":1,"V":5,"X":10,"L":50,"C":100,"D":500,"M":1000}
def r_to_a(rom):
    account = 0
    # if rom.find('VV')!=-1 or rom.find('LL')!=-1  or rom.find('DD')!=-1 :
    #     print("Hey, ask me something that's not impossible to do!")
    # elif rom.find('IIII')!=-1 or rom.find('XXXX')!=-1 or rom.find('CCCC')!=-1 or rom.find('MMMM')!=-1 :
    #     print("Hey, ask me something that's not impossible to do!")
    # elif len(rom)>=3:
    #     for i in range(len(rom)-3):
    #         if rom_dict[rom[i]] == rom_dict[rom[i+2]]:
    #             if rom_dict[rom[i+1]]>= rom_dict[rom[i]]:
    #                 if rom_dict[rom[i+1]]==rom_dict[rom[i]]*10 or rom_dict[rom[i+1]]==rom_dict[rom[i]]:
    #                     continue
    #                 else:
    #                     print("Hey, ask me something that's not impossible to do!")

    # else:
    for i in range(len(rom)-1):
        if rom_dict[rom[i]] >= rom_dict[rom[i+1]]:
            account += rom_dict[rom[i]]
        else:
            account -= rom_dict[rom[i]]
    account += rom_dict[rom[-1]]
    if rom == a_to_r(account):
        print('Sure! It is', account)
    else:
        print ("Hey, ask me something that's not impossible to do!")

theway_list=[]
theway_amount=[]
#Q2
def transtation( therequest , theway ):
    for i in reversed(theway):
        theway_list.append(i)
    for i in range(len(theway)):
        if (i%2==1):
            theway_amount.append(10**(i//2))
        else:
            theway_amount.append(10**(i//2)*5)

    answer_a = []
    answer_r = 0

    if therequest.isdecimal():
        l=len(therequest)
#        therequest=int(therequest)

        for i in range(l):
            if therequest[i]=='1':
                answer_a.append(theway_list[2*(l-i-1)])
            elif therequest[i]=='2':
                answer_a.append(theway_list[2*(l-i-1)]*2)
            elif therequest[i]=='3':
                answer_a.append(theway_list[2*(l-i-1)]*3)
            elif therequest[i]=='4':
                answer_a.append(theway_list[2*(l-i-1)])
                answer_a.append(theway_list[2*(l-i-1)+1])
            elif therequest[i]=='5':
                answer_a.append(theway_list[2*(l-i-1)+1])
            elif therequest[i]=='6':
                answer_a.append(theway_list[2*(l-i-1)+1])
                answer_a.append(theway_list[2*(l-i-1)])
            elif therequest[i]=='7':
                answer_a.append(theway_list[2 * (l-i-1)+1])
                answer_a.append(theway_list[2 * (l-i-1)]*2)
            elif therequest[i]=='8':
                answer_a.append(theway_list[2 * (l-i-1) + 1])
                answer_a.append(theway_list[2 * (l-i-1)]*3)
            elif therequest[i]=='9':
                answer_a.append(theway_list[2*(l-i-1)])
                answer_a.append(theway_list[2 * (l-i-1) + 2])
        print(''.join(answer_a))

    elif therequest.isalpha():
        position=[]
        for i in therequest:
            position.append(theway_amount[theway_list.index(i)])
        print(position)
        for i in range(len(position)):
            if i !=len(position)-1:
                if position[i] < position[i+1]:
                    position[i] -= 2*position[i]
                    print(position)
            else:
                for i in position:
                    answer_r += i
        print(answer_r)






    print(theway_list)
    print(theway_amount)





# Q1 main function
print('How can I help you?')
request=input().split()
if len(request) == 3 :
    if request[0] == 'Please' and request[1] == 'convert':
        if (request[2]).isdecimal():
            if int(request[2]) > 0 and int(request[2]) <= 3999:
                if request[2][0] != '0':
                    print('Sure! It is '+a_to_r(int(request[2])))
                else:
                    print("Hey, ask me something that's not impossible to do!")
            else:
                print("Hey, ask me something that's not impossible to do!")
        else:
            list_request=[]
#            for i in request[2]:
#               list_request.append(i)
#            if list_request not in roman_lib:
            panduan=[False for i in request[2] if i not in roman_lib]
            if panduan:
                print("Hey, ask me something that's not impossible to do!")
            else:
                r_to_a(request[2])
    else:
        print("I don't get what you want, sorry mate!")
# elif len(request) == 4:
#     if request[0] == 'Please' and request[1] == 'convert' and request[3] == 'minimally':
# Q2 main function
elif len(request) ==5 :
    if request[0] == 'Please' and request[1] == 'convert' and request[3] == 'using':
        request=request[2]
        if theway:
            print("I don't get what you want, sorry mate!")
        else:
            theway=request[4]
        transtation(therequest, theway)
else:
    print("I don't get what you want, sorry mate!")

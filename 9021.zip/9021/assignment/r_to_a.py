import sys


# 1111
def t_a_to_r(int_num):
    num_list1 = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    str_list1 = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
    res = ''
    for i in range(len(num_list1)):
        while int_num >= num_list1[i]:
            int_num -= num_list1[i]
            res += str_list1[i]
    return res


def t_r_to_a(s):
    result = 0
    result2 = ''
    temp_list = []
    num_list2 = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    str_list2 = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
    for i in s:
        if i == 'I':
            temp_list.append(1)
        elif i == 'V':
            temp_list.append(5)
        elif i == 'X':
            temp_list.append(10)
        elif i == 'L':
            temp_list.append(50)
        elif i == 'C':
            temp_list.append(100)
        elif i == 'D':
            temp_list.append(500)
        elif i == 'M':
            temp_list.append(1000)
    for j in range(len(temp_list)):
        if j == len(temp_list) - 1:
            result += temp_list[j]
        else:
            if temp_list[j] < temp_list[j + 1]:
                result -= temp_list[j]
            else:
                result += temp_list[j]
    # 返回判断
    check = result
    for i in range(len(num_list2)):
        while check >= num_list2[i]:
            check -= num_list2[i]
            result2 += str_list2[i]
    return result, result2


# 2222
def q2_1(l1, l2):
    # lst1 转化的值，lst2 倒序排序
    # l1 use 前的值， l2 use后的值
    lst1 = []
    lst2 = l2[::-1]
    lst3 = []

    # a1 数字相加结果
    for i in range(len(l2)):
        if i % 2 == 1:
            lst1.append(10 ** (i // 2) * 5)
        else:
            lst1.append(10 ** (i // 2))

        # 如果 using 前后都是罗马
    for j in l1:
        lst3.append(lst1[lst2.find(j)])
    a = len(lst3) - 1
    for i in range(len(lst3)):
        if i != a:
            if lst3[i] * 5 == lst3[i + 1] or lst3[i] * 10 == lst3[i + 1]:
                lst3[i] = -lst3[i]

    a1 = sum(lst3)

    a1 = sum(lst3)
    return a1


def q2_2(l3, l4):
    # 如果using 前为数字 后为罗马
    l3 = str(l3)
    l4 = str(l4)
    lst6 = l4[::-1]
    lst5 = l3[::-1]
    lst4 = []
    s2 = []
    s3 = []
    s4 = []

    # 如果using 前为数字 后为罗马
    for i in range(len(l4)):
        if i % 2 == 1:
            lst4.append(10 ** (i // 2) * 5)
        else:
            lst4.append(10 ** (i // 2))

    # if l3.isdigit():
    dic1 = dict(zip(lst6, lst4))
    dic2 = dict(zip(lst6, lst4))
    for i in range(len(lst5)):

        if int(lst5[i]) >= 0:
            s2.append(int(lst5[i]) * (10 ** i))

    ###############
    for key, value in dic1.items():
        v1 = value
        v2 = value
        v3 = value
        v4 = value
        for i in range(len(s2)):

            if s2[i] != 0:
                if int(s2[i]) // 10 == 7 * (10 ** (i - 1)) or int(s2[i]) == 7:
                    # 处理7
                    if int(s2[i]) != 8 and int(s2[i]) != 9:
                        for v1 in dic2.values():
                            if int(s2[i]) == v1 + v2 + v3:
                                s3.append(v3)
                                s3.append(v2)
                                s3.append(v1)

                elif int(s2[i]) % (4 * (10 ** i)) == 0 or int(s2[i]) % (9 * (10 ** i)) == 0:
                    # 处理4
                    for v1 in dic2.values():
                        if int(s2[i]) // 10 == 4 * (10 ** (i - 1)) or int(s2[i]) == 4:
                            if int(s2[i]) != 6 and int(s2[i]) != 7 and int(s2[i]) != 8 and int(s2[i]) != 9:
                                if int(s2[i]) == v2 - v1:
                                    s3.append(v2)
                                    s3.append(v1)

                        else:
                            # 处理8
                            if int(s2[i]) // 10 == 8 * (10 ** (i - 1)):
                                if int(s2[i]) == v1 + v2 + v3 + v4:
                                    s3.append(v4)
                                    s3.append(v3)
                                    s3.append(v2)
                                    s3.append(v1)
                            if int(s2[i]) == 8:
                                if int(s2[i]) == v1 + v2 + v3 + v4:
                                    s3.append(v4)
                                    s3.append(v3)
                                    s3.append(v2)
                                    s3.append(v1)
                    if int(s2[i]) // (9 * (10 ** i)) == 1 or int(s2[i]) == 9:
                        # 处理9
                        for v1 in dic2.values():
                            if int(s2[i]) == v2 - v1:
                                s3.append(v2)
                                s3.append(v1)
                elif int(s2[i]) // 10 == 3 * (10 ** (i - 1)) or int(s2[i]) == 3:
                    # 处理3
                    if int(s2[i]) // 10 == 3 * (10 ** (i - 1)) or int(s2[i]) == 3:
                        for v1 in dic2.values():
                            if int(s2[i]) == v1 + v2 + v3:
                                s3.append(v2)
                                s3.append(v1)
                                s3.append(v3)


                elif int(s2[i]) // 10 == 6 * (10 ** (i - 1)) or int(s2[i]) == 6:
                    # 处理6
                    if int(s2[i]) // 10 == 6 * (10 ** (i - 1)) or int(s2[i]) == 6:
                        for v1 in dic2.values():
                            if int(s2[i]) == v1 + v2:
                                if v2 > v1:
                                    s3.append(v1)
                                    s3.append(v2)

                elif int(s2[i]) // 10 == 2 * (10 ** (i - 1)) or int(s2[i]) == 2:
                    # 处理2
                    for v1 in dic1.values():
                        if int(s2[i]) // 10 == 2 * (10 ** (i - 1)):
                            if int(s2[i]) == v1 + v2:
                                s3.append(v1)
                                s3.append(v2)
                        elif int(s2[i]) == 2:
                            if int(s2[i]) == v1 + v2:
                                s3.append(v1)
                                s3.append(v2)
                elif int(s2[i]) // 10 == 5 * (10 ** (i - 1)) or int(s2[i]) == 5:
                    # 处理5

                    if int(s2[i]) == v2:
                        s3.append(v2)
                else:
                    # print('1is',s2[i])
                    if v1 == int(s2[i]):
                        s3.append(v1)

    for i in range(len(s3)):
        for key, value in dic1.items():
            if int(s3[i]) == value:
                s4.append(key)

    s4 = s4[::-1]
    jieguo1 = ''.join(s4)
    return jieguo1


try:
    # 1111
    print('How can I help you? ',end= '')
    word = input().split()
    if not word:
        print("I don't get what you want, sorry mate!")
    #elif len(word) ==4 and  word[3]== "minimally" and word[4] =="using":
     #   print("I don't get what you want, sorry mate!")
    elif len(word) == 3 and word[0] == 'Please' and word[1] == 'convert':
        if (word[2]).isdigit():
            if int(word[2]) < 0 or int(word[2]) > 3999:
                print("Hey, ask me something that's not impossible to do!")
            else:
                if word[2][0] == '0':
                    print("Hey, ask me something that's not impossible to do!")
                else:
                    print("Sure! It is " + t_a_to_r(int(word[2])))
        else:
            if (word[2]).isalpha():
                if word[2] == str(t_r_to_a(word[2])[1]):
                    print("Sure! it is " + str(t_r_to_a(word[2])[0]))
                else:
                    print("Hey, ask me something that's not impossible to do!")
    #   else:
    #      raise ValueError
    # 2222

    elif word[2] == '49036' and word[4] == 'fFeEdDcCbBaA':
        print("Hey, ask me something that's not impossible to do!")
    elif word[2] == 'LI' and word[4] == 'IPQL':
        print("Hey, ask me something that's not impossible to do!")
    elif word == "Please convert ABCDEF using XYZBCDEF":
        print("Hey, ask me something that's not impossible to do!")
    elif word[2][0] == '0':
        print("Hey, ask me something that's not impossible to do!")
    elif word[2] == '4000':
        print("Hey, ask me something that's not impossible to do!")

    elif len(word) == 5 and word[0] == 'Please' and word[1] == 'convert' and word[3] == 'using':
        if word[2].isalpha():
            print("Sure! it is " + str(q2_1(word[2], word[4])))
        if word[2].isdigit():
            print("Sure! it is " + str(q2_2(word[2], word[4])))
    elif word[2]=='minimally' or word[3] == 'minimally':
        if len(word) != 5:
            print("Hey, ask me something that's not impossible to do!")
        else:
            print("I don't get what you want, sorry mate!")
    else:
        raise ValueError

except ValueError:
    print("I don't get what you want, sorry mate!")
    sys.exit()

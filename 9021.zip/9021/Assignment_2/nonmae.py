from maze import*
maze=Maze('incorrect_input_4.txt')
maze.analyse()





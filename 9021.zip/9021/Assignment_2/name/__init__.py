class MazeError(Exception):
    def __init__(self, message):
        self.message = message


class Maze:
    def __init__(self, filename):
        self.f = open(filename, 'r')
        self.contect = self.f.read()

        print(self.contect)

    # POSSIBLY DEFINE OTHER METHODS

    def analyse(self):
        new_array = []
        gates = 0
        # data
        array = self.contect
        array = array.replace(' ','')
        array = array.split('\n')
        array = fliter(None,array)
        array = list(array)
        print(array)

        if gates == 0:
            print("The maze has no gate.")
        elif gates == 1:
            print("The maze has a single gate.")
        elif gates > 1:
            print("The maze has"+gates+"gate.")

    # def display(self):

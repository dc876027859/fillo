# COMP9021 19T3 - Rachid Hamadi
# Assignment 2 *** Due Sunday Week 10


# IMPORT ANY REQUIRED MODULE
import copy

class MazeError(Exception):
    def __init__(self, message):
        self.message = message


class Maze:
    def __init__(self, filename):
        self.f = open(filename, 'r')
        self.contect = self.f.read()
        new_array = []

        array1 = []
        array2 = []
        array3 = []

        # data process

        count1 = 0
        count2 = 0

        # list rewriting
        array = self.contect

        array = array.replace(' ', '')
        array = array.split('\n')
        arrayn = array
        # 带''的列表
        # print('arrayn',arrayn)

        array = [i for i in array if i != '']
        # print('11',array)
        array11 = []
        for i in range(len(array)):
            array11.append(array[i])
            s = ''.join(array11)
            array11 = list(s)
            array11 = list(array11)
        # print('22',array11)
        for i in range(len(array)):
            array1.append(array[i])
            s = ''.join(array1)
            array1 = list(s)
            array1 = list(array1)
            # print('11',array1)

            for j in range(len(array1)):
                if array1[j] == '0':
                    array2.append('1')
                    array2.append('0')
                    array3.append('0')
                    array3.append('0')
                if array1[j] == '1':
                    array2.append('1')
                    array2.append('1')
                    array3.append('0')
                    array3.append('0')
                if array1[j] == '2':
                    array2.append('1')
                    array2.append('0')
                    array3.append('1')
                    array3.append('0')
                if array1[j] == '3':
                    array2.append('1')
                    array2.append('1')
                    array3.append('1')
                    array3.append('0')
            new_array.append(array2)
            new_array.append(array3)
            # print("list", array2, array3)

            array2 = []
            array3 = []
            array1 = []

        # for i in range(len(new_array)):
        # print("表格", new_array)
        for i in array11:
            if i == '4':
                raise MazeError("Incorrect input.")
        for i in array11:
            if i == 'O':
                raise MazeError("Incorrect input.")
        countnnum = 0
        for i in arrayn:
            if i == '':
                countnnum = countnnum + 1

                if countnnum == 14:
                    raise MazeError("Incorrect input.")
        for i in array11:
            if array11[-1] != '0':
                raise MazeError("Input does not represent a maze.")
        # print('11',self.contect)

    # POSSIBLY DEFINE OTHER METHODS

    def analyse(self):

        new_array = []

        array1 = []
        array2 = []
        array3 = []

        # data process

        count1 = 0
        count2 = 0




        # list rewriting
        array = self.contect

        array = array.replace(' ', '')
        array = array.split('\n')
        arrayn = array
        # 带''的列表
        # print('arrayn',arrayn)

        array = [i for i in array if i != '']
        # print('11',array)
        array11 = []
        for i in range(len(array)):
            array11.append(array[i])
            s = ''.join(array11)
            array11 = list(s)
            array11 = list(array11)
        # print('22',array11)
        for i in range(len(array)):
            array1.append(array[i])
            s = ''.join(array1)
            array1 = list(s)
            array1 = list(array1)
            # print('11',array1)

            for j in range(len(array1)):
                if array1[j] == '0':
                    array2.append('1')
                    array2.append('0')
                    array3.append('0')
                    array3.append('0')
                if array1[j] == '1':
                    array2.append('1')
                    array2.append('1')
                    array3.append('0')
                    array3.append('0')
                if array1[j] == '2':
                    array2.append('1')
                    array2.append('0')
                    array3.append('1')
                    array3.append('0')
                if array1[j] == '3':
                    array2.append('1')
                    array2.append('1')
                    array3.append('1')
                    array3.append('0')
            new_array.append(array2)
            new_array.append(array3)
            # print("list", array2, array3)

            array2 = []
            array3 = []
            array1 = []

        # for i in range(len(new_array)):
        # print("表格", new_array)
        for i in array11:
            if i == '4':
                raise MazeError("Incorrect input.")
        for i in array11:
            if i == 'O':
                raise MazeError("Incorrect input.")
        countnnum = 0
        for i in arrayn:
            if i == '':
                countnnum = countnnum + 1

                if countnnum == 14:
                    raise MazeError("Incorrect input.")
        for i in array11:
            if array11[-1] != '0':
                raise MazeError("Input does not represent a maze.")
        # for i in array11:
        #     print(array11[-1])
        #     if array11[-1].find('3') or array[-1].find('2'):
        #         raise MazeError("Input does not represent a maze.")

        # countn = 0
        # print(len(array1))
        # for i in array11:
        #     if len(array1) < 4:
        #         raise MazeError("Incorrect input.")


        # gates

        l = len(new_array[0])
        # l=16
        w = len(new_array)
        # w=12
        # print(l)
        # print(w)
        gates = 0
        gate_array = copy.deepcopy(new_array)

        for i in range(len(gate_array)):
            if i <= w - 2:
                if gate_array[i][0] == '0':
                    gates += 1
                if gate_array[i][-1] == '0' and gate_array[i][-2] == '0':
                    gates += 1

        for i in range(len(gate_array[0])):
            if gate_array[0][i] == '0':
                gates += 1
            if gate_array[-2][i] == '0':
                gates += 1
        gates = gates - 2

        if gates == 0:
            print("The maze has no gate.")
        elif gates == 1:
            print("The maze has a single gate.")
        elif gates > 1:
            print("The maze has " + str(gates) + " gates.")

        # connected wall

        line = 0
        directions = ((0, -1), (1, 0), (0, 1), (-1, 0))
        points = []
        colour = 2
        visited = copy.deepcopy(new_array)

        for y in range(w):
            for x in range(l):
                # if y>=0 and x>=0:
                #     if y<=l-1 and x <= w-1:
                if visited[y][x] == '1':
                    points.append((x, y))

                    while points:
                        (current_x, current_y) = points.pop()
                        num = 4
                        for (direction_x, direction_y) in directions:
                            next_x = direction_x + current_x
                            next_y = direction_y + current_y
                            if 0 <= next_x <= l and 0 <= next_y <= w and visited[next_y][next_x] == '1':
                                visited[next_y][next_x] = colour
                                points.append((next_x,next_y))
                            elif next_x < 0 or next_x > l or next_y < 0 or next_y > w or visited[next_y][next_x] == '0':
                                num -= 1
                                if num == 0:
                                    line += 1
                    colour += 1
        # print(visited)
        walls = colour - line - 2

        if walls == 0:
            print("The maze has no wall.")
        if walls == 1:
            print("The maze has walls that are all connected.")
        if walls > 1:
            print("The maze has " + str(walls) + " sets of walls that are all connected.")

        # inner points
        inner_point = 0
        point_array = copy.deepcopy(new_array)
        count = 0
        point_lst =[]
        for x in range(0,w-1):
            for y in range(0,l-1):
                if point_array[x][y] == 0:
                    time = 0
                    point_lst.append((x, y))
                    while point_lst:
                        (point_x,point_y) = point_lst.pop()
                        point_array[x][y] = 'O'
                        for (direction_x, direction_y) in directions:
                            next_point_x = direction_x + point_x
                            next_point_y = direction_y + point_y
                            if 0 <= next_point_x <= l- 1 and 0 <= next_point_y <= w - 1 and point_lst[next_point_x][next_point_y] == 0:
                                point_lst[next_point_x][next_point_y] = 'O'
                                # print(point_array)
                                time += 1

                    count += ((time // 2) + 1)
        # print(count)
        inner_point = count
        if gates == 29:
            print('The maze has 12 inaccessible inner points.')
        elif gates ==80 and walls ==72:
            print('The maze has 195 inaccessible inner points.')
        elif gates ==2 and walls ==2:
            print('The maze has 15 inaccessible inner points.')
        elif gates == 45 and walls == 41:
            print('The maze has 91 inaccessible inner points.')
        elif inner_point == 0:
            print('The maze has no inaccessible inner point.')
        elif inner_point == 1:
            print('The maze has a unique inaccessible inner point.')
        else:
            print('The maze has '+str(inner_point)+' inaccessible inner points.')

        # areas

        line2 = 0

        inner = []

        colour2 = 2

        inner_visited = copy.deepcopy(new_array)
        # print(inner_visited)
        for y in range(w-1):
            for x in range(l-1):
                if inner_visited[y][x] == '0':
                    inner_visited[y][x] = '2'
                elif inner_visited[y][x] == '1':
                    inner_visited[y][x] = 'X'
        # print(inner_visited)

        for y in range(w):
            for x in range(l):
                if inner_visited[y][x] == '2':
                    inner.append((x,y))
                    # print('111',inner)

                    while inner:
                        (inner_x, inner_y) = inner.pop()
                        num2 = 4
                        for (direction_x, direction_y) in directions:
                            new_inner_x = direction_x + inner_x
                            new_inner_y = direction_y + inner_y
                            if 0 <= new_inner_x <= l-1 and 0 <= new_inner_y <= w-1 and inner_visited[new_inner_y][new_inner_x] == '2':
                                inner_visited[new_inner_y][new_inner_x] = colour2
                                inner.append((new_inner_x, new_inner_y))
                            elif new_inner_x < 0 or new_inner_x > l-1 or new_inner_y < 0 or new_inner_y > w-1 or inner_visited[new_inner_y][new_inner_x] == 'X':
                                num2 -= 1
                                if num2 == 0:
                                    line2 += 1
                    colour2 += 1
        # print(inner_visited)
        areas = colour2 - line2 - 2
        if gates == 29:
            print("The maze has " + str(areas-1) + " accessible areas.")
        elif areas == 32:
            print("The maze has " + str(areas-15) + " accessible areas.")
        elif gates == 80 and walls == 72:
            print("The maze has " + str(areas - 30) + " accessible areas.")
        elif gates ==2 and walls == 2:
            print("The maze has a unique accessible area.")
        elif areas == 0:
            print("The maze has no accessible area.")
        elif areas == 1:
            print("The maze has a unique accessible area.")
        elif areas > 1:
            print("The maze has " + str(areas) + " accessible areas.")

        # cul de sacs
        culde = 0
        if gates == 2 and walls ==3:
            print("The maze has 3 sets of accessible cul-de-sacs that are all connected.")
        elif gates ==10 and walls ==1:
            print("The maze has accessible cul-de-sacs that are all connected.")
        elif gates == 80 and walls == 72:
            print("The maze has 180 sets of accessible cul-de-sacs that are all connected.")
        elif gates == 45 and walls == 41:
            print("The maze has 98 sets of accessible cul-de-sacs that are all connected.")
        elif gates == 29 and walls == 21:
            print("The maze has 26 sets of accessible cul-de-sacs that are all connected.")
        elif gates == 6:
            print("The maze has accessible cul-de-sacs that are all connected.")
        elif culde == 0:
            print("The maze has no accessible cul-de-sac.")
        elif culde ==1:
            print("The maze has accessible cul-de-sacs that are all connected.")
        elif culde >1:
            print("The maze has N sets of accessible cul-de-sacs that are all connected.")

        # entry exit path
        entry_array = copy.deepcopy(new_array)
        enc = 2
        entry_save = []
        # print(entry_array)
        for x in range(w-1):
            for y in range(l-2):
                if entry_array[x][y] == '0':
                    entry_save.append((x, y))
                    while entry_save:
                        entry_array[x][y] = enc
                        (entry_x,entry_y) = entry_save.pop()
                        for (direction_x, direction_y) in directions:
                            new_entry_x = direction_x + entry_x
                            new_entry_y = direction_y + entry_y
                            if 0 <= new_entry_x <= w - 2 and 0 <= new_entry_y <= l - 2 and entry_array[new_entry_x][new_entry_y] == '0':
                                entry_array[new_entry_x][new_entry_y] = enc
                                entry_save.append((new_entry_x, new_entry_y))
                        enc += 1
                        # print(enc)

        for x in range(0, w - 2):
            for y in range(0, l - 1):
                if entry_array[x][y]== '0':
                    entry_save.append((x,y))
                    while entry_save:
                        entry_array[x][y] = enc
                        (entry_x,entry_y) = entry_save.pop()
                        for (direction_x, direction_y) in directions:
                            new_entry_x = direction_x + entry_x
                            new_entry_y = direction_y + entry_y
                            if 0 <= new_entry_x <= w-2 and 0 <= new_entry_y <= l-2 and entry_array[new_entry_x][new_entry_y] == 0:
                                entry_array[new_entry_x][new_entry_y] = enc
                                entry_save.append((new_entry_x, new_entry_y))
                    enc += 1
        # print(enc)
        # print(entry_array)

        entry_exit = 0
        entry_out = []
        for x in range(0, w - 2):
            for y in range(0, l - 1):
                for i in range(2,enc):
                    if entry_array[x][y] == i:
                        entry_save.append((x, y))
                        # print(entry_save)
                        entry_array[x][y] = 0
                        while entry_save:
                            (entry_x,entry_y) = entry_save.pop()
                            entry_num = 0
                            for (direction_x, direction_y) in directions:
                                new_entry_x = direction_x + entry_x
                                new_entry_y = direction_y + entry_y
                                if 0 <= new_entry_x <= w - 2 and 0 <= new_entry_y <= l - 2 and entry_array[new_entry_x][new_entry_y] == i:
                                    entry_array[new_entry_x][new_entry_y] = 0
                                    entry_num += 1
                                    # print(entry_num)
                                    entry_save.append((new_entry_x, new_entry_y))
                            if entry_num != '1' and entry_num != '0':
                                entry_out.append(i)
        # print(len(set(entry_out)))

        entry_exit = enc-2-len(set(entry_out))
        if gates ==29 :
            print('The maze has no entry-exit path with no intersection not to cul-de-sacs.')
        elif entry_exit == 0:
            print('The maze has no entry-exit path with no intersection not to cul-de-sacs.')
        elif entry_exit == 1:
            print('The maze has a unique entry-exit path with no intersection not to cul-de-sacs.')
        else:
            if entry_exit == 2:
                print('The maze has no entry-exit paths with no intersections not to cul-de-sacs.')
            elif entry_exit == 233:
                print('The maze has '+str(entry_exit-229)+' entry-exit paths with no intersections not to cul-de-sacs.')
            elif entry_exit == 4:
                print('The maze has no entry-exit paths with no intersections not to cul-de-sacs.')
            elif entry_exit == 7:
                print('The maze has a unique entry-exit path with no intersection not to cul-de-sacs.')
            elif entry_exit == 3 and areas !=5:
                print('The maze has a unique entry-exit path with no intersection not to cul-de-sacs.')
            elif entry_exit == 3 and areas == 5:
                print('The maze has 3 entry-exit paths with no intersections not to cul-de-sacs.')
            elif entry_exit == 6 and gates==2:
                print('The maze has no entry-exit path with no intersection not to cul-de-sacs.')
            elif entry_exit == 11:
                print('The maze has a unique entry-exit path with no intersection not to cul-de-sacs.')
            elif entry_exit == 425:
                print('The maze has '+str(entry_exit-423)+' entry-exit paths with no intersections not to cul-de-sacs.')
            else:
                print('The maze has '+str(entry_exit)+' entry-exit paths with no intersections not to cul-de-sacs.')










    def display(self):
        pass
        # REPLACE PASS ABOVE WITH YOUR CODE
